/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class NightShiftDetail extends AppCompatActivity {
    FirebaseDatabase database;
    DatabaseReference myRef,ref;
    List<AttendenceList> list;
    RecyclerView Precyclerview;
    TextView tv,tc;
    private ProgressDialog pd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_night_shift_detail);
        tv=(TextView)findViewById(R.id.datetxt) ;
        tc=(TextView)findViewById(R.id.count) ;
        Precyclerview=(RecyclerView)findViewById(R.id.NightRecylerview);
        pd=new ProgressDialog(this);
        Intent abintent=getIntent();

        tv.setText(abintent.getExtras().getString("date"));
        database = FirebaseDatabase.getInstance();
        myRef = database.getReferenceFromUrl("https://pushpindialimited.firebaseio.com/Employee Information/Night Shift");
        //   DatabaseReference mmyref=myRef.child("Absent Attendence");
        ref=myRef.child(abintent.getExtras().getString("date"));
        // DatabaseReference dref=ref.child()
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                int size = (int) dataSnapshot.getChildrenCount();
                tc.setText("Total Night requests :" +size);
                pd.setMessage("Wait...");
                pd.setCancelable(true);
                pd.setCanceledOnTouchOutside(false);
                pd.show();
                list = new ArrayList<>();
                // StringBuffer stringbuffer = new StringBuffer();
                for(DataSnapshot dataSnapshot1 :dataSnapshot.getChildren()){
                    Intent abintent=getIntent();

                    tv.setText(abintent.getExtras().getString("date"));
                    //  database = FirebaseDatabase.getInstance();
                    //myRef = database.getReference("Attendence List");
                    //     DatabaseReference mmyref=myRef.child("Absent Attendence");

                    EmployeeInformation userdetails = dataSnapshot1.getValue(EmployeeInformation.class);
                    String naame=userdetails.getNaame();
                    String employeeno=userdetails.getEmployeeno();
                    String locationla=userdetails.getLocationla();
                    String locationlo=userdetails.getLocationlo();
                    String time=userdetails.getTime();
                    String captureimage=userdetails.getCaptureImageUrl();
                    String report=userdetails.getReport();
                    AttendenceList listdata = new AttendenceList(naame,locationla,locationlo,time,report,employeeno,captureimage);
                    // listdata.setNaame(dataSnapshot1.child(abintent.getExtras().getString("date")).getValue(EmployeeInformation.class).getNaame());
                    // listdata.setEmployeeno(dataSnapshot1.child(abintent.getExtras().getString("date")).getValue(EmployeeInformation.class).getEmployeeno());
                    // listdata.setNaame(listdata.getNaame());
                    //  listdata.setEmployeeno(listdata.getEmployeeno());
                    //  String naame=userdetails.getNaame();
                    //String employeeno=userdetails.getEmployeeno();
                    //listdata.setNaame(naame);
                    //listdata.setEmployeeno(employeeno);
                    list.add(listdata);
                    pd.dismiss();
                    // Toast.makeText(MainActivity.this,""+name,Toast.LENGTH_LONG).show();

                }
                Intent abintent=getIntent();
            String date =   abintent.getExtras().getString("date");
              NightShiftRecyclerAdapter recycler = new NightShiftRecyclerAdapter(NightShiftDetail.this,list,date);
                RecyclerView.LayoutManager layoutmanager = new LinearLayoutManager(NightShiftDetail.this);
                Precyclerview.setLayoutManager(layoutmanager);
                Precyclerview.setItemAnimator( new DefaultItemAnimator());
                Precyclerview.setAdapter(recycler);
                pd.dismiss();

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Toast.makeText(NightShiftDetail.this, "Network problem check in detail", Toast.LENGTH_SHORT).show();
                //  Log.w(TAG, "Failed to read value.", error.toException());
            }
        });


        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);
    }

}

