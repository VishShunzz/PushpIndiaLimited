/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

class MyNotificationManager {
    private Context mctx;
    private static MyNotificationManager mInstance;

    private MyNotificationManager(Context context){
        mctx=context;

    }
    public  static  synchronized MyNotificationManager getInstance(Context context){
        if(mInstance==null){
            mInstance=new MyNotificationManager(context);
        }
        return mInstance;

    }

    public  void displayNotification(String title,String body){
        NotificationCompat.Builder mBuiler=new NotificationCompat.Builder(mctx, Constants.CHANNEL_ID )
                .setSmallIcon(R.drawable.ic_stat_local_florist)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true);


        Intent notiIntent= new Intent(mctx, NotifyActivity.class);
        notiIntent.putExtra("title",title);
        notiIntent.putExtra("body",body);
        //handling click on notification
        PendingIntent pendingIntent=PendingIntent.getActivity(mctx,0,notiIntent,PendingIntent.FLAG_UPDATE_CURRENT);
        mBuiler.setContentIntent(pendingIntent);
        NotificationManager mNotificationManager=(NotificationManager)mctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (mNotificationManager!=null){
            mNotificationManager.notify(1,mBuiler.build());
        }


    }
}
