/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessageService extends FirebaseMessagingService {

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        if(remoteMessage.getNotification()!=null) {
            String title = remoteMessage.getNotification().getTitle();
            String body = remoteMessage.getNotification().getBody();
            MyNotificationManager.getInstance(getApplicationContext()).displayNotification(title,body);

        }
    }
}
