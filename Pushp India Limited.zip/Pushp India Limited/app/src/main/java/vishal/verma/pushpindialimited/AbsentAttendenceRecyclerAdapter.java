/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

public class AbsentAttendenceRecyclerAdapter extends RecyclerView.Adapter<AbsentAttendenceRecyclerAdapter.MyHolder> {
    Context context;
    List<AttendenceList> attendencelistdata;
    View.OnClickListener callback;

    public AbsentAttendenceRecyclerAdapter(Context context,List<AttendenceList> attendencelistdata) {
        this.context = context;
        this.attendencelistdata = attendencelistdata;
    }

    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.absent_list, parent, false);

        MyHolder myHolder = new MyHolder(view);
        return myHolder;
    }


    public void onBindViewHolder(final MyHolder holder, final int position) {
        final AttendenceList data = attendencelistdata.get(position);
       // DatabaseReference databaseReference=
       // final  String visit=data.get(position);
        holder.vnaame.setText(data.getNaame());
        holder.vemployeeno.setText(data.getEmployeeno());
        holder.vtime.setText(data.getTime());
        holder.vlocationla.setText(data.getLocationla());
        holder.vlocationlo.setText(data.getLocationlo());
        holder.vreport.setText(data.getReport());
        Picasso.with(context).load(data.getCaptureImageUrl()).placeholder(R.drawable.button_profile_logo).into(holder.Pik);
        //holder.vaddress.setText(data.getAddress());
        holder.absentRelative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               context=v.getContext();

                Intent i=new Intent(context,AbsentReportingActivity.class);
                i.putExtra("Employeeno",data.getEmployeeno());
                i.putExtra("Naame",data.getNaame());
                i.putExtra("Report",data.getReport());
                i.putExtra("Time",data.getTime());
                i.putExtra("Locationla",data.getLocationla());
                i.putExtra("Locationlo",data.getLocationlo());
                i.putExtra("CaptureImage",data.getCaptureImageUrl());
              //  i.putExtra("Date",data.get);
context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return attendencelistdata.size();
    }


    class MyHolder extends RecyclerView.ViewHolder  {
        TextView vnaame, vemployeeno,vreport,vlocationlo,vlocationla,vtime;
        RelativeLayout absentRelative;
CircleImageView Pik;
        public MyHolder(final View itemView) {
            super(itemView);
            vreport = (TextView) itemView.findViewById(R.id.Report);
            vlocationlo=(TextView)itemView.findViewById(R.id.LocationLo);
            vlocationla=(TextView)itemView.findViewById(R.id.LocationLa);
            vtime=(TextView)itemView.findViewById(R.id.DateTime);
            vnaame = (TextView) itemView.findViewById(R.id.alt_name);
            vemployeeno = (TextView) itemView.findViewById(R.id.alt_employeeNo);
            Pik=(CircleImageView)itemView.findViewById(R.id.profilePic);

            absentRelative = (RelativeLayout) itemView.findViewById(R.id.absentParent);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // int visit= getPosition();
                    //  int visit =getAdapterPosition();
                    // Intent i2= new Intent(itemView.getContext(),AbsentReportingActivity.class);
                    // i2.putExtra("Date",visit);
                    // itemView.getContext().startActivity(i2);

                }
            });

        }

    }

}