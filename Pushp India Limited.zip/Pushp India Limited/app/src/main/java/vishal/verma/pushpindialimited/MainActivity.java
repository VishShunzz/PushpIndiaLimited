/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import com.google.firebase.FirebaseApp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {
    private ProgressDialog PD;
   // public  static final String CHANNEL_ID="MY CHANNEL ID";
    //public  static final String CHANNEL_NAME="MY CHANNEL NAME";
    //public  static final String CHANNEL_DESC="MY DESCRIPTION";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirebaseApp.initializeApp(this);
        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION}, 1);

        }


        //for notificationManger
        NotificationManager mNotificationManager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
            NotificationChannel mChannel=new NotificationChannel(Constants.CHANNEL_ID,Constants.CHANNEL_NAME,NotificationManager.IMPORTANCE_HIGH);
            mChannel.setDescription(Constants.CHANNEL_DESC);
            mChannel.enableLights(true);
            mChannel.setLightColor(Color.BLUE);
            mChannel.enableVibration(true);
            mChannel.setVibrationPattern(new long[]{100,200,300,400,500,600,500,300,200,600,1000,100,200});
            mNotificationManager.createNotificationChannel(mChannel);

        }

        PD = new ProgressDialog(this);
        PD.setMessage("Loading...");
        PD.setCancelable(false);
        PD.setCanceledOnTouchOutside(false);
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
        builder.setMessage("Really Exit ??");
        builder.setTitle("Exit");
        builder.setCancelable(false);
        builder.setPositiveButton("Ok",new MyListener());
        builder.setNegativeButton("Cancel",null);
        builder.show();
    }

    public void admin(View view) {

        PD = new ProgressDialog(this);
        PD.setMessage("Loading...");
        PD.setCancelable(false);
        PD.setCanceledOnTouchOutside(false);
            PD.show();
            Intent intent2=new Intent(MainActivity.this, AdminLogin.class);
            startActivity(intent2);
            PD.dismiss();



    }

    public void Employee(View view) {

        PD = new ProgressDialog(this);
        PD.setMessage("Loading...");
        PD.setCancelable(false);
        PD.setCanceledOnTouchOutside(false);

            PD.show();
            Intent intent = new Intent(MainActivity.this, Employee_LogIn.class);
            startActivity(intent);
            PD.dismiss();

    }

    public class MyListener implements DialogInterface.OnClickListener{

        @Override
        public void onClick(DialogInterface dialog, int which) {
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(0);
        }
    }


}
