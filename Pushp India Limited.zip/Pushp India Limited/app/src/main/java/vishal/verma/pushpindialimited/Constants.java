/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

public class Constants {

    public  static final String CHANNEL_ID="MY CHANNEL ID";
    public  static final String CHANNEL_NAME="MY CHANNEL NAME";
    public  static final String CHANNEL_DESC="MY DESCRIPTION";

}
