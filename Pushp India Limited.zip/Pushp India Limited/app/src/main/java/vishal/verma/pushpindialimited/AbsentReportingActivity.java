/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import androidx.appcompat.app.AppCompatActivity;
import de.hdodenhof.circleimageview.CircleImageView;

public class AbsentReportingActivity extends AppCompatActivity {
private TextView Naame,employeeNo,locationlo,locationla,date,report;
private LinearLayout linearLayout;
private CircleImageView cv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_absent_reporting);
        cv=(CircleImageView)findViewById(R.id.captureImage);
Naame=(TextView) findViewById(R.id.fullName);
employeeNo=(TextView)findViewById(R.id.employeeNo);
locationla=(TextView)findViewById(R.id.location1LA);
locationlo=(TextView)findViewById(R.id.location1LO);
date=(TextView)findViewById(R.id.datetime);
report=(TextView)findViewById(R.id.Report);
linearLayout=(LinearLayout)findViewById(R.id.Aloca);
        Intent i=getIntent();

        Naame.setText(i.getExtras().getString("Naame"));
        employeeNo.setText(i.getExtras().getString("Employeeno"));
        locationlo.setText("Longitude : "+i.getExtras().getString("Locationlo"));
        locationla.setText("Latitude : "+i.getExtras().getString("Locationla"));
        date.setText(i.getExtras().getString("Time"));
        report.setText(i.getExtras().getString("Report"));
        Picasso.with(this).load(i.getExtras().getString("CaptureImage")).placeholder(R.drawable.button_profile_logo).into(cv);
        //Intent i2=getIntent();
//report.setText(i2.getExtras().getString("Date"));
      //  dr= FirebaseDatabase.getInstance().getReferenceFromUrl("https://pushpindialimited.firebaseio.com/Employee Information/Attendence List/Absent Attendence/11-02-2019");
 // DR=dr.child(employeeNo.getText().toString()+" "+Naame.getText().toString());
       // dr= FirebaseDatabase.getInstance().getReference(i2.getExtras().getString("Date"));
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
cv.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent i=getIntent();
        Intent p1=new Intent(AbsentReportingActivity.this,PhotoViewActivity.class);
        // imageView.buildDrawingCache();
        //Bitmap bitmap = imageView.getDrawingCache();
        p1.putExtra("name",Naame.getText().toString());
        p1.putExtra("photo",i.getExtras().getString("CaptureImage"));
        startActivity(p1);
    }
});
linearLayout.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v){
        Intent mapIntent=getIntent();
        //0,0 defines current location of user, if we want navigation we can use "google.navigate:q=latitude,longitude"
        Uri gmmIntentUri = Uri.parse("geo:0,0?q="+mapIntent.getExtras().getString("Locationla")+","+mapIntent.getExtras().getString("Locationlo"));
        Intent mapIntent2 = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent2.setPackage("com.google.android.apps.maps");
        startActivity(mapIntent2);

    }
});
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);

    }

}
