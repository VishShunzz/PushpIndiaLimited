/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

public class AttendanceActivity extends AppCompatActivity {
private ImageView captureImage;
private EditText currentReport ;
    private TextView currentLocationLa,currentLocationLo,currentTime;
    private StorageReference SR1;
private String captureImageUrl,current_state;

String id,Curi,user1;
private FirebaseStorage FS;
private FirebaseDatabase FD;
private DatabaseReference DR1,DR2;
private StorageTask mCaptureTask;
private Button presentB,absentB;
private ProgressDialog pd;
    private Uri uri,downloadUri,photoURI;
    private static final int REQUEST_CODE=101;
  //  private StorageReference SR;
    //private ProgressDialog PD;
    FirebaseUser user;
    LocationManager lm;
    String longi,lati;
//    private  FirebaseUser user1;
    private static  final int RL=1;
    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);
        presentB=(Button)findViewById(R.id.presentB);
        absentB=(Button)findViewById(R.id.absentB);
        currentLocationLa=(TextView)findViewById(R.id.currentLocationLa);
        currentLocationLo=(TextView)findViewById(R.id.currentLocationLo);
        currentTime=(TextView)findViewById(R.id.currentDateTime);
        currentReport=(EditText)findViewById(R.id.report);
    captureImage=(ImageView)findViewById(R.id.captureImage);
    pd=new ProgressDialog(this,ProgressDialog.STYLE_SPINNER);
    firebaseAuth= FirebaseAuth.getInstance();
   user1=firebaseAuth.getCurrentUser().getUid();
current_state="unmarked";




        Intent intent = getIntent();


        if (ActivityCompat.checkSelfPermission(AttendanceActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ) {
            ActivityCompat.requestPermissions(AttendanceActivity.this, new String[]{Manifest.permission.CAMERA}, 1);
            return;
        }

    firebaseAuth= FirebaseAuth.getInstance();
       // user = firebaseAuth.getCurrentUser();
        // set date and time
        Date time= Calendar.getInstance().getTime();
        currentTime.setText(time.toString());
        currentLocationLo.setText("Longitude : "+intent.getExtras().getString("locationlo"));
        currentLocationLa.setText("Latitude : "+intent.getExtras().getString("locationla"));



    SR1= FirebaseStorage.getInstance().getReferenceFromUrl("gs://pushpindialimited.appspot.com/Attendance Pics");
    DR1= FirebaseDatabase.getInstance().getReferenceFromUrl("https://pushpindialimited.firebaseio.com/Employee Information/Attendence Activity");
        DR2= FirebaseDatabase.getInstance().getReferenceFromUrl("https://pushpindialimited.firebaseio.com/Employee Information");//"https://pushpindialimited.firebaseio.com/Employee Information"
      user = firebaseAuth.getCurrentUser();
        id= firebaseAuth.getUid();
checkInformation();


   captureImage.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View v) {
          dispatchTakePictureIntent();
           // CaptureImage();
         //  saveUserInformation();
       }
    });

            presentB.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(current_state=="unmarked") {
                        if (TextUtils.isEmpty(currentReport.getText().toString())&& downloadUri.equals("")) {
                            Toast.makeText(AttendanceActivity.this, "Please Fill Reporting Field \n Otherwise you doesn't mark as Present or Absent \n It can be lead action from PIL to you", Toast.LENGTH_LONG).show();
                        } else {
                            PretrieveTimeAndLocation();
                        }
                    }
                    /*else  if(current_state=="Marked") {
                        currentReport.setFocusable(false);
                        presentB.setText("Marked Present");
                        currentReport.setText("You already mark your attendance as present");
                        presentB.setFocusable(false);
                        presentB.setBackgroundColor(Color.BLUE);
                        presentB.setText("Marked Present");
                        presentB.setVisibility(View.VISIBLE);
                        absentB.setVisibility(View.INVISIBLE);
                    }*/


                }
            });
            absentB.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (current_state == "unmarked") {
                        if (TextUtils.isEmpty(currentReport.getText().toString())&& downloadUri.equals("")) {
                            Toast.makeText(AttendanceActivity.this, "Please Fill Reporting Field \n Otherwise you doesn't mark as Present or Absent \n It can be lead action from PIL to you", Toast.LENGTH_LONG).show();
                        } else {
                            AretrieveTimeAndLocation();
                        }
                    }
                    /*else  if(current_state=="Marked") {
                        currentReport.setFocusable(false);
                        absentB.setText("Marked Present");
                        currentReport.setText("You already mark your attendance as absent");
                        absentB.setFocusable(false);
                        absentB.setBackgroundColor(Color.RED);
                        absentB.setText("Marked Absent");
                        absentB.setVisibility(View.VISIBLE);
                        presentB.setVisibility(View.INVISIBLE);
                    }
                    */
                }
                
            });
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

    }

    private void checkInformation() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("dd-MM-yyyy");
        final String strDate = mdformat.format(calendar.getTime());
        DR2.child("Attendence Activity")//.child(intent.getExtras().getString("employeeno") + "  " + intent.getExtras().getString("name"))
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Intent intent = getIntent();
                        if (dataSnapshot.hasChild("Present Attendence/"+strDate+"/"+intent.getExtras().getString("employeeno")+"  "+intent.getExtras().getString("name"))) {
                            String req = dataSnapshot.child("Present Attendence").child(strDate).child(intent.getExtras().getString("employeeno")+"  "+intent.getExtras().getString("name"))
                                   .child("naame").getValue().toString();
                            if (req.equals(intent.getExtras().getString("name"))) {
                                current_state = "Marked";
                                currentReport.setFocusable(false);
                                presentB.setText("Marked Present");
                                currentReport.setText("You already mark your attendance as present");
                                presentB.setFocusable(false);
                                presentB.setBackgroundColor(Color.BLUE);
                                presentB.setText("Marked Present");
                                captureImage.setFocusable(false);
                                presentB.setCompoundDrawablesWithIntrinsicBounds( R.drawable.ic_check_box_black_24dp, 0, 0, 0);
                                presentB.setVisibility(View.VISIBLE);
                                absentB.setVisibility(View.INVISIBLE);

                            }
                        }else if(dataSnapshot.hasChild("Absent Attendence/"+strDate+"/"+intent.getExtras().getString("employeeno")+"  "+intent.getExtras().getString("name"))){
                            String req = dataSnapshot.child("Absent Attendence").child(strDate).child(intent.getExtras().getString("employeeno")+"  "+intent.getExtras().getString("name"))
                                    .child("naame").getValue().toString();
                            if (req.equals(intent.getExtras().getString("name"))) {
                                current_state = "Marked";
                                currentReport.setFocusable(false);
                                presentB.setText("Marked Absent");
                                currentReport.setText("You already mark your attendance as absent");
                                presentB.setFocusable(false);
                                captureImage.setFocusable(false);
                                presentB.setCompoundDrawablesWithIntrinsicBounds( R.drawable.ic_check_box_black_24dp, 0, 0, 0);
                                presentB.setBackgroundColor(Color.RED);
                                presentB.setText("Marked Absent");
                                presentB.setVisibility(View.VISIBLE);
                                absentB.setVisibility(View.INVISIBLE);

                            }

                        }else current_state="unmarked";

                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);


    }
    private void PretrieveTimeAndLocation() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("dd-MM-yyyy");
        String strDate = mdformat.format(calendar.getTime());

        Intent intent = getIntent();

        String locatla=intent.getExtras().getString("locationla");
        String locatlo=intent.getExtras().getString("locationlo");
        String Date=currentTime.getText().toString();
        String report=currentReport.getText().toString();
        String usid=intent.getExtras().getString("usid");
        String name=intent.getExtras().getString("name");
        String employeeno=intent.getExtras().getString("employeeno");
        String image=downloadUri.toString();

        EmployeeInformation Lt=new EmployeeInformation(locatla,locatlo,Date,report,employeeno,name,image);


       DatabaseReference mmref=DR1.child("Present Attendence");
        DatabaseReference mref =mmref.child(mdformat.format(calendar.getTime()));//child(user.getUid())// mref.child(user.getUid()).setValue(Lt)
        mref.child(intent.getExtras().getString("employeeno")+"  "+intent.getExtras().getString("name")).setValue(Lt).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Calendar calendar = Calendar.getInstance();
                    SimpleDateFormat mdformat = new SimpleDateFormat("yyyy/MM/dd");
                    String strDate = mdformat.format(calendar.getTime());
                 DR2.child("Employee Detail").child(user1).child("Present").child(strDate).setValue("P").addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toast.makeText(AttendanceActivity.this, "You Mark as Present", Toast.LENGTH_SHORT).show();

                            Intent i1=new Intent(AttendanceActivity.this,Eemployee_Collection.class);
                            startActivity(i1);
                            current_state="Marked";
                            presentB.setFocusable(false);
                            presentB.setBackgroundColor(Color.BLUE);
                            presentB.setText("Marked Present");
                            presentB.setVisibility(View.VISIBLE);
                            absentB.setVisibility(View.INVISIBLE);

                        }
                    });


                    //pd.dismiss();
                } else
                    Toast.makeText(AttendanceActivity.this, "Some error "+"\n"+"Please try Again", Toast.LENGTH_SHORT).show();
                // Intent i1=new Intent(AddEmployeeActivity.this,AdminActivity.class);
                //startActivity(i1);
                //  mref.child(user.getUid())setValue(Lt);
            }
        });
    }
    private void AretrieveTimeAndLocation() {

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("dd-MM-yyyy");
        String strDate = mdformat.format(calendar.getTime());


        Intent intent = getIntent();

        String locatla=intent.getExtras().getString("locationla");
        String locatlo=intent.getExtras().getString("locationlo");
        String Date=currentTime.getText().toString();
        String report=currentReport.getText().toString();
        String usid=intent.getExtras().getString("usid");
        String name=intent.getExtras().getString("name");
        String employeeno=intent.getExtras().getString("employeeno");
        String image=downloadUri.toString();

        EmployeeInformation Lt=new EmployeeInformation(locatla,locatlo,Date,report,employeeno,name,image);

        DatabaseReference mmref=DR1.child("Absent Attendence");//child(user.getUid())// mref.child(user.getUid()).setValue(Lt)
      DatabaseReference mref= mmref.child((mdformat.format(calendar.getTime())));
       mref.child(intent.getExtras().getString("employeeno")+"  "+intent.getExtras().getString("name")).setValue(Lt).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {

                    Calendar calendar = Calendar.getInstance();
                    SimpleDateFormat mdformat = new SimpleDateFormat("yyyy/MM/dd");
                    String strDate = mdformat.format(calendar.getTime());
                    DR2.child("Employee Detail").child(user1).child("Absent").child(strDate).setValue("A").addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(AttendanceActivity.this, "You Marked as Absent", Toast.LENGTH_SHORT).show();

                                Intent i1 = new Intent(AttendanceActivity.this, Eemployee_Collection.class);
                                startActivity(i1);
                                current_state = "Marked";
                                presentB.setFocusable(false);
                                presentB.setBackgroundColor(Color.MAGENTA);
                                presentB.setText("Marked Absent");
                                presentB.setVisibility(View.VISIBLE);
                                absentB.setVisibility(View.INVISIBLE);

                               // pd.dismiss();
                            } else {
                                Toast.makeText(AttendanceActivity.this, "Some error " + "\n" + "Please try Again", Toast.LENGTH_SHORT).show();

                            }

                        }
                        // Intent i1=new Intent(AddEmployeeActivity.this,AdminActivity.class);
                        //startActivity(i1);
                        //  mref.child(user.getUid())setValue(Lt);
                    });
                }
        });
    }

   /* private void getLocation() {
        if(ActivityCompat.checkSelfPermission(AttendanceActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(AttendanceActivity.this , new String[]{Manifest.permission.ACCESS_FINE_LOCATION},RL);
        }else{
            Location lo=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if(lo!=null){
                double llati=lo.getLatitude();
                double llongi=lo.getLongitude();
                lati=String.valueOf(llati);
                longi=String.valueOf(llongi);
                currentLocation.setText("Longitude :"+longi+"\n"+" Latitude :"+lati );
            }else
                Toast.makeText(AttendanceActivity.this, " Failed to Trace Your Location"+"\n"+"Retry", Toast.LENGTH_SHORT).show();
        }
    }

*/

    @Override
    protected void onActivityResult(int requestCode, int resultCode,Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {//&& data != null && data.getData() != null) {
            // uri = data.getData();
            // captureImage.setImageURI(uri);
            CropImage.activity(photoURI)
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .setAspectRatio(1, 1)
                    .start(this);
        }

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {


            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                Uri resultUri = result.getUri();

                captureImage.setImageURI(resultUri);
                uri = resultUri;


                pd.setMessage("Saving...");
                pd.setCanceledOnTouchOutside(false);
                pd.setCancelable(false);
                pd.show();
                //     Uri resulturi=result.getUri();


                final StorageReference profileImageRef =
                        FirebaseStorage.getInstance().getReference().child("Attendance Pics/").child(resultUri.getLastPathSegment());//firebaseAuth.getCurrentUser().getUid()+ ".jpg");//.child(uri.getLastPathSegment());//+ ".jpg") ;
                profileImageRef.putFile(resultUri).
                        continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                            @Override
                            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                                if (!task.isSuccessful()) {
                                    pd.dismiss();
                                    throw task.getException();

                                } else {
                                    Handler handler = new Handler();
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toast.makeText(AttendanceActivity.this, "Uploading in Progress ", Toast.LENGTH_SHORT).show();
                                            pd.dismiss();
                                        }
                                    }, 500);
                                }
                                return profileImageRef.getDownloadUrl();
                            }
                        })
                        // Continue with the task to get the download URL
                        //   return profileImageRef.getDownloadUrl();


                        // }
                        .addOnCompleteListener(new OnCompleteListener<Uri>() {
                            @Override
                            public void onComplete(@NonNull final Task<Uri> task) {
                                if (task.isSuccessful()) {
                                    downloadUri = task.getResult();
                                    pd.dismiss();


                                }
                            }
                        })


                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                pd.dismiss();
                                Toast.makeText(AttendanceActivity.this, "Some error in uploading \n Try Again", Toast.LENGTH_SHORT).show();
                            }
                        });
/*                            .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                            //for settin progreesbar in timer
                        }
                    });*/

                 } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                  Exception error = result.getError();
                  Toast.makeText(AttendanceActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                 }
            }

        }

    String mCurrentPhotoPath;

    private File createImageFile() throws IOException {
// Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new     Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

// Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.getAbsolutePath();
        return image;
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
// Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File...
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                photoURI = FileProvider.getUriForFile(this,
                        "vishal.verma.pushpindialimited.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, REQUEST_CODE);
            }
        }
    }

    }



