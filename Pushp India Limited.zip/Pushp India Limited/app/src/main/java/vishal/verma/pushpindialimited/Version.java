/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Version extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_version);
    }
}
