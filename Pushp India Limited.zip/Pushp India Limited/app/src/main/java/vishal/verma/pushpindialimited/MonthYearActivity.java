/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MonthYearActivity extends AppCompatActivity {
    private TextView month, year;
    private Button next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_month_year);
        month = (TextView) findViewById(R.id.month);
        year = (TextView) findViewById(R.id.year);
        next = (Button) findViewById(R.id.nextButton);


        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                     if (year.getText().toString().trim().length() < 4 || year.getText().toString().trim().length() > 4) {
                    year.setError(" Enter year number in four digits.");
                    Toast.makeText(MonthYearActivity.this, "Enter year number in proper way.", Toast.LENGTH_LONG).show();
                    year.requestFocus();
                    return;

                }else if (month.getText().toString().trim().length() < 2 || month.getText().toString().trim().length() > 2) {
                    month.setError(" Enter month number in two digits.");
                    month.requestFocus();
                    Toast.makeText(MonthYearActivity.this, "Enter 0 before the digit if you entering single digit.", Toast.LENGTH_LONG).show();
                    return;
                }

                else
                    if (year.getText().toString().length() == 4 && month.getText().toString().length() == 2) {
                    Intent nextIntent = new Intent(MonthYearActivity.this, MonthlyStatus.class);
                    nextIntent.putExtra("Month", month.getText().toString().trim());
                    nextIntent.putExtra("Year", year.getText().toString().trim());
                    startActivity(nextIntent);
                    //  month.setError(" Enter year number in four digits.");

                }
            }
        });
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);
    }
}
