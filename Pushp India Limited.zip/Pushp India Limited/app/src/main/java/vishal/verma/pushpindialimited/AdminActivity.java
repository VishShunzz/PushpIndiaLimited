/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class AdminActivity extends AppCompatActivity {
EditText search;
RecyclerView recyclerView;
DatabaseReference dr;
FirebaseUser user;
ArrayList<String> fullNameList;
    ArrayList<String> employeeNoList;
    ArrayList<String> profilePicList;
    ArrayList<String>phoneList;
    ArrayList<String>aadharList;
    ArrayList<String>departmentList;
    ArrayList<String>emailList;
ArrayList<String>user_idList;
    ArrayList<String>Get_user_id;
    SearchAdapter searchAdapter;
    Button b1,b2,b3;



    private final int REQ_CODE_SPEECH_INPUT = 100;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
      //  b1=(Button)findViewById(R.id.button);
        b2=(Button)findViewById(R.id.button2);
        //b3=(Button)findViewById(R.id.button4);
        b1=(Button)findViewById(R.id.button5);
        search=(EditText) findViewById(R.id.search);
        recyclerView=(RecyclerView)findViewById(R.id.recyclerView);
        dr= FirebaseDatabase.getInstance().getReference();
        user= FirebaseAuth.getInstance().getCurrentUser();
        recyclerView.setHasFixedSize(true);

        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        fullNameList=new ArrayList<String>();
        employeeNoList=new ArrayList<String>();
        profilePicList=new ArrayList<String>();
        aadharList=new ArrayList<String>();
        phoneList=new ArrayList<String>();
        emailList=new ArrayList<String>();
        departmentList=new ArrayList<String>();
        user_idList=new ArrayList<String>();
       Get_user_id=new ArrayList<String>();
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(!s.toString().isEmpty()) {
                    setAdapter(s.toString());
                }
                    else {
                        fullNameList.clear();
                        employeeNoList.clear();
                        profilePicList.clear();
                        Get_user_id.clear();

                        aadharList.clear();
                        departmentList.clear();
                        emailList.clear();
                        user_idList.clear();
                        phoneList.clear();
                        recyclerView.removeAllViews();
                    }
                }
            });
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
b1.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        startActivity(new Intent(AdminActivity.this,AttendenceCheck.class));
    }
});
    }
    private void setAdapter(final String searchString){

        dr.child("Employee Information").child("Employee Detail").addListenerForSingleValueEvent(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                fullNameList.clear();
                employeeNoList.clear();
               profilePicList.clear();
                aadharList.clear();
                departmentList.clear();
                emailList.clear();
                user_idList.clear();
                phoneList.clear();
                Get_user_id.clear();
                recyclerView.removeAllViews();

                int counter = 0;

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                  EmployeeInformation std=snapshot.getValue(EmployeeInformation.class);
                        String Getuser_id = snapshot.child("Get_user_id").getValue(String.class);
                        String fullname = snapshot.child("naame").getValue(String.class);
                        String employeeno = snapshot.child("employeeno").getValue(String.class);
                    String email = snapshot.child("email").getValue(String.class);
                    String aadhar = snapshot.child("aadhar").getValue(String.class);
                    String phone = snapshot.child("phone").getValue(String.class);
                    String deparment = snapshot.child("department").getValue(String.class);
                    String userid = snapshot.child("user_id").getValue(String.class);


                    String profilePic=snapshot.child("Profile_image").getValue(String.class);
                     //   EmployeeInformation profilePic = snapshot.child("ProfilePic").getValue(EmployeeInformation.class);

                    //if (fullname.toLowerCase().contains(searchString.toLowerCase())) {
                    if (fullname.toLowerCase().toString().contains(searchString.toLowerCase().toString())) {
                        fullNameList.add(fullname);
                        employeeNoList.add(employeeno);
                       profilePicList.add(profilePic);
                       phoneList.add(phone);
                       aadharList.add(aadhar);
                       departmentList.add(deparment);
                       emailList.add(email);
                       user_idList.add(userid);
                       Get_user_id.add(Getuser_id);
                        counter++;

                 //   } else if (employeeno.toLowerCase().contains(searchString.toLowerCase())) {
                    } else if (employeeno.contains(searchString)) {
                        fullNameList.add(fullname);
                        employeeNoList.add(employeeno);
                       profilePicList.add(profilePic);
                        phoneList.add(phone);
                        aadharList.add(aadhar);
                        departmentList.add(deparment);
                        emailList.add(email);
                        user_idList.add(userid);
                        Get_user_id.add(Getuser_id);
                        counter++;
                    }
                    else if (deparment.toLowerCase().contains(searchString.toLowerCase())) {
                        fullNameList.add(fullname);
                        employeeNoList.add(employeeno);
                        profilePicList.add(profilePic);
                        phoneList.add(phone);
                        aadharList.add(aadhar);
                        departmentList.add(deparment);
                        emailList.add(email);
                        user_idList.add(userid);
                        Get_user_id.add(Getuser_id);
                        counter++;
                    }
                    else if (phone.contains(searchString)) {
                        fullNameList.add(fullname);
                        employeeNoList.add(employeeno);
                        profilePicList.add(profilePic);
                        phoneList.add(phone);
                        aadharList.add(aadhar);
                        departmentList.add(deparment);
                        emailList.add(email);
                        user_idList.add(userid);
                        Get_user_id.add(Getuser_id);
                        counter++;
                    }else if (aadhar.contains(searchString)) {
                        fullNameList.add(fullname);
                        employeeNoList.add(employeeno);
                        profilePicList.add(profilePic);
                        phoneList.add(phone);
                        aadharList.add(aadhar);
                        departmentList.add(deparment);
                        emailList.add(email);
                        user_idList.add(userid);
                        Get_user_id.add(Getuser_id);
                        counter++;
                    }else if (email.contains(searchString)) {
                        fullNameList.add(fullname);
                        employeeNoList.add(employeeno);
                        profilePicList.add(profilePic);
                        phoneList.add(phone);
                        aadharList.add(aadhar);
                        departmentList.add(deparment);
                        emailList.add(email);
                        user_idList.add(userid);
                        Get_user_id.add(Getuser_id);
                        counter++;
                    }
                    else if (userid.contains(searchString)) {
                        fullNameList.add(fullname);
                        employeeNoList.add(employeeno);
                        profilePicList.add(profilePic);
                        phoneList.add(phone);
                        aadharList.add(aadhar);
                        departmentList.add(deparment);
                        emailList.add(email);
                        user_idList.add(userid);
                        Get_user_id.add(Getuser_id);
                        counter++;
                    }
                    if (counter == 20) {
                        break;

                    }
                    }
                searchAdapter =new SearchAdapter(AdminActivity.this,fullNameList,employeeNoList,profilePicList,phoneList,aadharList,departmentList,emailList,user_idList,Get_user_id);
                recyclerView.setAdapter(searchAdapter);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(AdminActivity.this, "Network Problem \n Try Again", Toast.LENGTH_SHORT).show();

            }
        });
    }
    public void fn(View view){
        //if(view==b1){
        //     Intent intent=new Intent(AdminActivity.this,DepartmentListActivity.class);
        //  startActivity(intent);
        // }
        //else
        if(view==b2){
            Intent intent=new Intent(AdminActivity.this,AddEmployeeActivity.class);
            startActivity(intent);
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.admin_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                startActivity(new Intent(this,MainActivity.class));
                break;

            case R.id.menuLogout:

                FirebaseAuth.getInstance().signOut();
                finish();
                startActivity(new Intent(this, MainActivity.class));

                break;
            case R.id.menuSetting:
                startActivity(new Intent(this, SettingActivity.class));

                break;
            case R.id.feedback:
                startActivity(new Intent(this,FeedBack_Activity.class));

                break;
            case R.id.Aboutus:
                 startActivity(new Intent(this,AboutUsActivity.class));

                break;
            case R.id.menuVersion:
                startActivity(new Intent(this, Version.class));

                break;
    }

        return true;
    }

    public void ANight_Shift(View view) {
        Intent nightIntent=new Intent(AdminActivity.this,NightShiftDateTime.class);
     //   nightIntent.putExtra("Night Shift","Night Shift");
        startActivity(nightIntent);
    }





    //for Speech to txt
    public void speechtoText(View view) {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
                getString(R.string.speech_prompt));
        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getApplicationContext(),
                    getString(R.string.speech_not_supported),
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onActivityResult( int requestCode,int resultCode,Intent data) {
        super.onActivityResult( requestCode,resultCode,data);
        switch (requestCode) {
            case REQ_CODE_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && null != data) {

                    ArrayList<String> result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    search.setText(result.get(0));
                }
                break;
            }

        }
    }
}
