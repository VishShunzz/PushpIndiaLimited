/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.squareup.picasso.Picasso;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class Eemployee_Collection extends AppCompatActivity {
   private TextView tvnaame, tvemplooyeeno;
   private String id, uid;
    public ProgressDialog pd;
    private FirebaseDatabase firebaseDatabase;
    private FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener listener;
    private DatabaseReference databaseReference,dr;
    private FirebaseUser user;
    private ImageView profileB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eemployee__collection);
        pd = new ProgressDialog(this, ProgressDialog.STYLE_SPINNER);

profileB=(ImageView)findViewById(R.id.Profile_button);
        tvnaame = (TextView) findViewById(R.id.naame);
        tvemplooyeeno = (TextView) findViewById(R.id.employeeno);


        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();

        user = firebaseAuth.getCurrentUser();
        id = firebaseAuth.getUid();
        databaseReference = firebaseDatabase.getReference();
        dr= FirebaseDatabase.getInstance().getReferenceFromUrl("https://pushpindialimited.firebaseio.com/Employee Information/Employee Detail");


        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        StateListener();
        fetchData();
getuidValue();

    }

    private void getuidValue() {
        dr.child(id).child("Get_user_id").setValue(id).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {

            }
        });

    }

    public void fetchData() {
        pd.setMessage("Fetching Information");
        pd.setCancelable(true);
        pd.setCanceledOnTouchOutside(false);
        pd.show();
        FirebaseInstanceId.getInstance().getInstanceId().addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
            @Override
            public void onComplete(@NonNull Task<InstanceIdResult> task) {
           if(task.isSuccessful()){
               String token=task.getResult().getToken();
               saveToken(token);
           }
            }
        });

        //databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {

        databaseReference.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                // try
                // Toast.makeText(StudentInformationActivity.this, "Hello bro Again", Toast.LENGTH_SHORT).show();
                // Iterable<DataSnapshot> children = dataSnapshot.getChildren();
                for (DataSnapshot stdSnapshot : dataSnapshot.getChildren()) {
                     EmployeeInformation std = stdSnapshot.child("Employee Detail").child(id).getValue(EmployeeInformation.class);
                   // EmployeeInformation std = new EmployeeInformation();
                    Log.i("Firebase Data -> ", stdSnapshot.toString());
                 // std.setNaame(stdSnapshot.child(id).getValue(EmployeeInformation.class).getNaame());
                  //std.setEmployeeno(stdSnapshot.child(id).getValue(EmployeeInformation.class).getEmployeeno());
                    tvnaame.setText(std.getNaame());
                    tvemplooyeeno.setText(std.getEmployeeno());
                    String image = std.getProfile_image();
                    Picasso.with(Eemployee_Collection.this).load(image).placeholder(R.drawable.button_profile_logo).into(profileB);
                  //uid=std.getToken();
                    pd.dismiss();
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(Eemployee_Collection.this, "Some problem in back firebase"+"\n"+ databaseError.getDetails(), Toast.LENGTH_SHORT).show();
pd.dismiss();
            }


        });
    }

    private void saveToken(String token) {
        FirebaseUser user = firebaseAuth.getCurrentUser();
        id=user.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Employee Information/Employee Detail");
        //DatabaseReference databaseReference1=databaseReference.child("Employee List with Detail");
        //  id=databaseReference.push().getKey();
        databaseReference.child(id).child("token").setValue(token).addOnCompleteListener(new OnCompleteListener<Void>() {;
            //databaseReference.child(et_employee_no.getText().toString()+" "+et_name.getText().toString()).setValue(stdinfo).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()) {



                }else
                    Toast.makeText(Eemployee_Collection.this, "Some error try again", Toast.LENGTH_SHORT).show();
                pd.dismiss();
            }

        });
    }


    @Override
    protected void onStart() {
        super.onStart();
        firebaseAuth.addAuthStateListener(listener);
    }


    @Override
    protected void onStop() {
        super.onStop();
        if (listener != null) {
            firebaseAuth.removeAuthStateListener(listener);
        }
    }
    public void MarkAttendence(View view) {

        Intent markIntent =new Intent(this, LocationOfUser.class);
        markIntent.putExtra("name", tvnaame.getText().toString());
        markIntent.putExtra("employeeno", tvemplooyeeno.getText().toString());
        //markIntent.putExtra("usid",uid);
        startActivity(markIntent);

    }

    public void EmployeeProfile(View view) {
        Intent profileIntent=new Intent(this, EmployeeInformationActivity.class);
        profileIntent.putExtra("Name",tvnaame.getText().toString());
        startActivity(profileIntent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.employee_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {


            case android.R.id.home:
                finish();
                startActivity(new Intent(Eemployee_Collection.this,MainActivity.class) );
                break;


            case R.id.menuLogout:

                FirebaseAuth.getInstance().signOut();
                finish();
                startActivity(new Intent(this, MainActivity.class));

                break;
            case R.id.menuSetting:
                startActivity(new Intent(this, SettingActivity.class));

                break;
            case R.id.menuStatus:
                startActivity(new Intent(this, MonthYearActivity.class));

                break;
            case R.id.feedback:
                 startActivity(new Intent(this, FeedBack_Activity.class));

                break;
            case R.id.Aboutus:
                startActivity(new Intent(this, AboutUsActivity.class));

                break;
            case R.id.menuVersion:
                startActivity(new Intent(this, Version.class));

                break;
        }

        return true;
    }

    public void StateListener() {
        listener = new FirebaseAuth.AuthStateListener() {

            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user == null) {
                    Toast.makeText(Eemployee_Collection.this, "You must be a Company member than Login", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        };

    }

    public void Night_Shift(View view) {
        Intent nightIntent =new Intent(this,NightShift.class);
        nightIntent.putExtra("name", tvnaame.getText().toString());
        nightIntent.putExtra("employeeno", tvemplooyeeno.getText().toString());
        //markIntent.putExtra("usid",uid);
        startActivity(nightIntent);
    }
}
