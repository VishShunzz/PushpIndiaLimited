/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class Employee_LogIn extends AppCompatActivity {
    private EditText iemail, ipassword;
   FirebaseAuth mAuth;
    Button  btnLogin;
    private String user;
    private ProgressDialog PD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_log_in);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);

            PD = new ProgressDialog(this);

            mAuth = FirebaseAuth.getInstance();
          //  user=mAuth.getCurrentUser().getUid();
            iemail = (EditText) findViewById(R.id.email);
            ipassword = (EditText) findViewById(R.id.password);
            btnLogin = (Button) findViewById(R.id.Login);
           // PD.show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);
    }

    private void userLogin() {
        PD.setMessage("Loading...");
        PD.setCancelable(false);
        PD.setCanceledOnTouchOutside(false);
        PD.show();
        String email = iemail.getText().toString().trim();
        String password = ipassword.getText().toString().trim();

        if (email.isEmpty()) {
            iemail.setError("Email is required");
            iemail.requestFocus();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            iemail.setError("Please enter a valid email");
            iemail.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            ipassword.setError("Password is required");
            ipassword.requestFocus();
            return;
        }

        if (password.length() < 6) {
            ipassword.setError("Minimum lenght of password should be 6");
            ipassword.requestFocus();
            return;
        }



        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful()) {
                    finish();
                    Intent intent = new Intent(Employee_LogIn.this, Eemployee_Collection.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    PD.dismiss();
                } else {
                    Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();
PD.dismiss();
                }
            }
        });
    }
    @Override
    protected void onStart() {
        super.onStart();

        if (mAuth.getCurrentUser() != null) {
            finish();

            startActivity(new Intent(this, Eemployee_Collection.class));
            PD.dismiss();
        }
    }
    public void User_login(View view){

        userLogin();



    }




}