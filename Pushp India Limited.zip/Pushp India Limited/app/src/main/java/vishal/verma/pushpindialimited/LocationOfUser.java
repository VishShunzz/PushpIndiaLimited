/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class LocationOfUser extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, com.google.android.gms.location.LocationListener {
    String longi, lati;
    private static final int RL = 1;
    private static final String TAG = "LocationOfUser";
    private GoogleApiClient mGoogleApiClient;
    private Location mLocation;
    private LocationManager locationManager;
    private LocationRequest mLocationRequest;
    private TextView currentLocationLo,currentLocationLa;
    private Button LocationButton;
    private ProgressDialog mPD;
private FirebaseAuth firebaseAuth;
private FirebaseUser user;
    private com.google.android.gms.location.LocationListener listener;
    private long UPDATE_INTERVAL = 2 * 1000;  /* 10 secs */
    private long FASTEST_INTERVAL = 2000; /* 2 sec */


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_of_user);
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, RL);

        if (getSupportActionBar() != null) {
         getSupportActionBar().setDisplayHomeAsUpEnabled(true);
         getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
firebaseAuth= FirebaseAuth.getInstance();
user=firebaseAuth.getCurrentUser();
        currentLocationLo = (TextView) findViewById(R.id.CurrentLocationLo);
        currentLocationLa = (TextView) findViewById(R.id.CurrentLocationLa);
        LocationButton = (Button) findViewById(R.id.LocationButton);
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        mPD = new ProgressDialog(this);

        if (ActivityCompat.checkSelfPermission(LocationOfUser.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(LocationOfUser.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(LocationOfUser.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, RL);
            return;
        }else{
            checkLocation(); // Write you code here if permission already given.
        }


        //check whether location service is enable or not in your  phone



        LocationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // mPD.setMessage("Wait..."+"\n"+"Tracing Your Location...");
                //  mPD.show();
                //  mPD.setCanceledOnTouchOutside(true);
                locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    Toast.makeText(LocationOfUser.this, " Failed to Trace Your Location" + "\n" + "Retry", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(currentLocationLo.getText().toString())) {

                    Toast.makeText(LocationOfUser.this, " Wait until your location doesn't get trace properly" + "\n" + "Retry", Toast.LENGTH_SHORT).show();

                }
                    else {
                        Intent i2 = getIntent();
                        Intent locate = new Intent(LocationOfUser.this, AttendanceActivity.class);
                        locate.putExtra("locationla", lati);
                        locate.putExtra("locationlo", longi);
                        locate.putExtra("name", i2.getExtras().getString("name"));
                        //locate.putExtra("usid",i2.getExtras().getString("usid"));
                        locate.putExtra("employeeno", i2.getExtras().getString("employeeno"));

                        startActivity(locate);
                    //}


                }
                // mPD.dismiss();
            }  // retrieveTimeAndLocation();
            });






    }


  @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
           finish();
       return super.onOptionsItemSelected(item);
   }

    @Override
    public void onConnected(Bundle bundle) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        startLocationUpdates();

        mLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);

        if(mLocation == null){
            startLocationUpdates();
        }
        if (mLocation != null) {

            // mLatitudeTextView.setText(String.valueOf(mLocation.getLatitude()));
            //mLongitudeTextView.setText(String.valueOf(mLocation.getLongitude()));
        } else {
            Toast.makeText(this, "Location not Detected", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.i(TAG, "Connection Suspended");
        mGoogleApiClient.connect();
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.i(TAG, "Connection failed. Error: " + connectionResult.getErrorCode());
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mGoogleApiClient != null) {
            mGoogleApiClient.connect();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mGoogleApiClient.isConnected()) {
            mGoogleApiClient.disconnect();
        }
    }

    protected void startLocationUpdates() {
        // Create the location request
        mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(UPDATE_INTERVAL)
                .setFastestInterval(FASTEST_INTERVAL);
        // Request location updates
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient,
                mLocationRequest, this);
        Log.d("reque", "--->>>>");
    }
    @Override
    public void onLocationChanged(Location location) {

        String msg = "Updated Location: " +
                Double.toString(location.getLatitude()) + "," +
                Double.toString(location.getLongitude());
        lati=String.valueOf(location.getLatitude());
        longi=String.valueOf(location.getLongitude());
        currentLocationLa.setText("Latitude :"+lati);
        currentLocationLo.setText("Longitude :"+longi);
        //  mLongitudeTextView.setText(String.valueOf(location.getLongitude() ));
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        // You can now create a LatLng Object for use with maps
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
    }

    private boolean checkLocation() {
        if(!isLocationEnabled())
            showAlert();
        return isLocationEnabled();
    }

    private void showAlert() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Enable Location")
                .setMessage("Your Locations Settings is set to 'Off'.\nPlease Enable Location to " +
                        "use this app")
                .setPositiveButton("Location Settings", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {

                        Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(myIntent);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {

                    }
                });
        dialog.show();
    }


    private boolean isLocationEnabled() {
        mPD.setMessage("Tracing");
        mPD.setCanceledOnTouchOutside(false);
        mPD.setCancelable(false);
        mPD.show();
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        mPD.dismiss();
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

    }

     /*   ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},RL);
        currentLocation=(TextView)findViewById(R.id.currentLocation);
        LocationButton=(Button)findViewById(R.id.LocationButton);
        mPD=new ProgressDialog(this);

        LocationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lm=(LocationManager)getSystemService(Context.LOCATION_SERVICE);
                if(!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)){
                    buiilAlertMessage();

                }else if(lm.isProviderEnabled(LocationManager.GPS_PROVIDER)){
                    getLocation();
                }
               // retrieveTimeAndLocation();
            }
        });
    }
    private void getLocation() {
        mPD.setMessage("Tracing..."+"\n"+"Wait...");
        mPD.show();
        if(ActivityCompat.checkSelfPermission(LocationOfUser.this, Manifest.permission.ACCESS_COARSE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(LocationOfUser.this , new String[]{Manifest.permission.ACCESS_FINE_LOCATION},RL);
            mPD.dismiss();
        }else{
            Location lo=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if(lo!=null){
                double llati=lo.getLatitude();
                double llongi=lo.getLongitude();
                lati=String.valueOf(llati);
                longi=String.valueOf(llongi);
                currentLocation.setText("Longitude :"+longi+"\n"+" Latitude :"+lati );
                mPD.dismiss();
           Intent locate=new Intent(LocationOfUser.this,AttendanceActivity.class);
                locate.putExtra("loacation", String.valueOf(currentLocation));
                startActivity(locate);
            }else
                mPD.dismiss();
                Toast.makeText(LocationOfUser.this, " Failed to Trace Your Location"+"\n"+"Retry", Toast.LENGTH_SHORT).show();
        }
    }
    private void buiilAlertMessage() {
        final AlertDialog.Builder builder=new AlertDialog.Builder(LocationOfUser.this);
        builder.setMessage("Please Turn On your GPS Connection")
                .setCancelable(false)
                .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
        final  AlertDialog alertDialog=builder.create();
        alertDialog.show();
    }*/

}
