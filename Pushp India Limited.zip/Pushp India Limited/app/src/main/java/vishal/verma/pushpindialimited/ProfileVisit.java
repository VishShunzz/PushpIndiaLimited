/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import androidx.appcompat.app.AppCompatActivity;
import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileVisit extends AppCompatActivity {
   private TextView tvname, tvemployeeno, tvaadhar, tvcontact, tvuser_id,tvdepartment, tvemail;
    private CircleImageView imageView;
    private Button attendanceStatus;
    public ProgressDialog pd;
    private String GetUserId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_visit);
        imageView = (CircleImageView) findViewById(R.id.imageView);
        attendanceStatus=(Button)findViewById(R.id.attendanceStatus);
        pd = new ProgressDialog(this, ProgressDialog.STYLE_SPINNER);
        pd.setMessage("Wait...");
        pd.setCancelable(true);
        pd.setCanceledOnTouchOutside(true);
        Intent visitIntent=getIntent();
setTitle(visitIntent.getExtras().getString("fullname"));
        tvname=(TextView)findViewById(R.id.textView14);
        tvuser_id =(TextView)findViewById(R.id.textViewid);
        tvdepartment=(TextView)findViewById(R.id.textViewMent);
        tvemail =(TextView)findViewById(R.id.textViewEid);
        tvemployeeno =(TextView)findViewById(R.id.textView17);
        tvaadhar =(TextView)findViewById(R.id.textView18);
        tvcontact=(TextView)findViewById(R.id.textView20);



        GetUserId=visitIntent.getExtras().getString("GetUserID");


        tvname.setText(visitIntent.getExtras().getString("fullname"));
        tvemail.setText(visitIntent.getExtras().getString("user_id"));//changed as a user_id
        tvdepartment.setText(visitIntent.getExtras().getString("department"));
        tvuser_id.setText(visitIntent.getExtras().getString("email"));//changed as a email
        tvemployeeno.setText(visitIntent.getExtras().getString("employeeno"));
        tvaadhar.setText(visitIntent.getExtras().getString("aadhar"));
        tvcontact.setText(visitIntent.getExtras().getString("phone"));
        Picasso.with(this).load(visitIntent.getExtras().getString("profilePic")).placeholder(R.drawable.button_profile_logo).into(imageView);


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=getIntent();
                Intent p1=new Intent(ProfileVisit.this,PhotoViewActivity.class);
                // imageView.buildDrawingCache();
                //Bitmap bitmap = imageView.getDrawingCache();
                p1.putExtra("name",tvname.getText().toString());
                p1.putExtra("photo",i.getExtras().getString("profilePic"));
                startActivity(p1);
            }
        });
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        attendanceStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent nextIntent=new Intent(ProfileVisit.this,AdminMonthYearActivity.class);
                nextIntent.putExtra("GetUserID",GetUserId);
                startActivity(nextIntent);

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);

    }

}
