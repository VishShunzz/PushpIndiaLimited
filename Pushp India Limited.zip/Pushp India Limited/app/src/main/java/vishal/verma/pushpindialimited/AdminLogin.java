/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class AdminLogin extends AppCompatActivity {
    private EditText userId, password;
    private FirebaseAuth mAuth;
    private Button button;
    private ProgressDialog PD;
    private DatabaseReference DR1;
    FirebaseAuth firebaseAuth;
    private String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);

            PD = new ProgressDialog(this);

            mAuth = FirebaseAuth.getInstance();
            userId = (EditText) findViewById(R.id.Username);
            password = (EditText) findViewById(R.id.password);
            DR1 = FirebaseDatabase.getInstance().getReferenceFromUrl("https://pushpindialimited.firebaseio.com/Employee Information/Employee Detail");
            button = (Button) findViewById(R.id.Login);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);
    }

    public void doOnClick(View view) {

        String user = userId.getText().toString();
        String pass = password.getText().toString();
        if (user.equals("nitin@pushpindia.net") && pass.equals("qwerty")) {
            PD.setMessage("Loading...");
            PD.setCancelable(true);
            PD.setCanceledOnTouchOutside(false);
            PD.show();


            if (user.isEmpty()) {
                userId.setError("Email is required");
                userId.requestFocus();
                return;
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(user).matches()) {
                userId.setError("Please enter a valid email");
                userId.requestFocus();
                return;
            }

            if (pass.isEmpty()) {
                password.setError("Password is required");
                password.requestFocus();
                return;
            }

            if (pass.length() < 6) {
                password.setError("Minimum lenght of password should be 6");
                password.requestFocus();
                return;
            }


            mAuth.signInWithEmailAndPassword(user, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {

                    if (task.isSuccessful()) {
                        finish();
                        Intent intent = new Intent(AdminLogin.this, AdminActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        PD.dismiss();
                    } else {
                        Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        PD.dismiss();
                    }
                }
            });
       /* if (user.equals("abc") && pass.equals("abc")) {
            Intent intent = new Intent(AdminLogin.this, AdminActivity.class);
            startActivity(intent);
            PD.dismiss();
        } else {
            Toast.makeText(AdminLogin.this, "Wrong Password", Toast.LENGTH_SHORT).show();
            PD.dismiss();
        }*/

        }else {
            Toast.makeText(this, "Wrong Credentials...", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
    ;
        if (mAuth.getCurrentUser() != null) {
            PD.setMessage("Loading...");
            PD.setCancelable(true);
            PD.setCanceledOnTouchOutside(false);
            PD.show();


            FirebaseUser user = mAuth.getCurrentUser();
            id=user.getUid();
            DR1//.child(intent.getExtras().getString("employeeno") + "  " + intent.getExtras().getString("name"))
                    .addValueEventListener(new ValueEventListener() {
                                               @Override
                                               public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                   if (dataSnapshot.hasChild(id)) {
                                                       String req = dataSnapshot.child(id).child("employeeno").getValue().toString();
                                                       if (req.equals("000")) {
                                                           finish();
                                                           startActivity(new Intent(AdminLogin.this, AdminActivity.class));
                                                           PD.dismiss();

                                                       }else{
                                                           finish();
                                                           FirebaseAuth.getInstance().signOut();
                                                           startActivity(new Intent(AdminLogin.this, AdminLogin.class));
                                                           PD.dismiss();
                                                       }
                                                   }
                                               }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
                                           });

        }else if (mAuth.getCurrentUser() != null){
            startActivity(new Intent(AdminLogin.this, AdminLogin.class));
            PD.dismiss();
        }
    }
}
