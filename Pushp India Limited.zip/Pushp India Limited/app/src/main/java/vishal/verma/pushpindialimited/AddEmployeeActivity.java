/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class AddEmployeeActivity extends AppCompatActivity {
    private EditText et_user_id,et_name,et_employee_no, et_aadhar_no,et_phone,et_email,et_password,et_department;
    ProgressDialog pd;
    Button b5;
    private String id;
    FirebaseAuth firebaseAuth;
    DatabaseReference databaseReference;
    //   CheckBox cb1,cb2,cb3,cb4,cb5,cb6,cb7,cb8;
    private FirebaseUser user;

    BroadcastReceiver receiver;
    FirebaseDatabase firebaseDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_employee);
        et_user_id=(EditText)findViewById(R.id.editText5);
        et_name=(EditText)findViewById(R.id.editText6);
        et_employee_no=(EditText)findViewById(R.id.editText7);
        et_aadhar_no =(EditText)findViewById(R.id.editText8);
        et_phone=(EditText)findViewById(R.id.editText9);
        et_email=(EditText)findViewById(R.id.editText10);
        et_password=(EditText)findViewById(R.id.editText11);
        et_department=(EditText)findViewById(R.id.textDepartmentno);
        b5=(Button)findViewById(R.id.button5);
//changed user_id as E-mail and E-mail as user_id in XML file
        firebaseAuth= FirebaseAuth.getInstance();
        pd=new ProgressDialog(this);


        id=firebaseAuth.getCurrentUser().getUid();

        if(firebaseAuth.getCurrentUser()!=null){
            Toast.makeText(AddEmployeeActivity.this, "Adding New Employee", Toast.LENGTH_SHORT).show();
            firebaseAuth.signOut();
        }
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);
    }


    public void fnRegister(View view) {
        Log.e("Entering ","In fn");

        final String email=et_user_id.getText().toString().trim()+"@pil.com";
        //change email as user_id and user_id as email
        //Always be in mind
        //It done for custom username for employee
        final String naame=et_name.getText().toString();
        final String employeeno=et_employee_no.getText().toString().trim();
        final String aadhar= et_aadhar_no.getText().toString().trim();
        final String phone=et_phone.getText().toString().trim();
        final String user_id=et_email.getText().toString().trim();
        final String password=et_password.getText().toString().trim();
        final String department=et_department.getText().toString().trim();
        final String token=null;
        final String Profile_image=null;
        final String Get_user_id=id;

        final String arr[]=new String[]{ email,naame,employeeno,aadhar,phone,user_id,password,department };
        for(int i=0;i<8;i++){
            if(TextUtils.isEmpty(arr[i])){

                Toast.makeText(AddEmployeeActivity.this, "Fill all Fields", Toast.LENGTH_SHORT).show();
                return ;
            }
        }
        if(password.length()<6){
            Toast.makeText(AddEmployeeActivity.this, "Password should contain min. 6 characters", Toast.LENGTH_SHORT).show();
            return ;
        }

        Log.e("Entering ", "In fn2");

        pd.setMessage("Registering User...");
        pd.setCancelable(false);
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pd.show();

        Log.e("Entering ", "In fn3");
        try{
            final   EmployeeInformation stdinfo=new EmployeeInformation(email,naame,employeeno,aadhar,phone,user_id,department,token,Profile_image);//,departments);
            firebaseAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(Task<AuthResult> task) {
                    pd.show();
                    if (task.isSuccessful()) {

                        saveInformation(stdinfo);

                    }
                    else {

                        if (task.getException() instanceof FirebaseAuthUserCollisionException) {

                            Toast.makeText(AddEmployeeActivity.this, "Already registered with this user ID", Toast.LENGTH_SHORT).show();
                            pd.dismiss();
                        }
                        else{

                            Toast.makeText(AddEmployeeActivity.this, "Something is going wrong !", Toast.LENGTH_SHORT).show();
                            pd.dismiss();
                        }
                    }
                }
            });
        }catch(Exception e){
            Log.e("Exception is ",e.toString());
            pd.dismiss();
        }



    }
    public void saveInformation(EmployeeInformation stdinfo){

        try {

            FirebaseUser user = firebaseAuth.getCurrentUser();
           id=user.getUid();
            databaseReference = FirebaseDatabase.getInstance().getReference("Employee Information/Employee Detail");
            //DatabaseReference databaseReference1=databaseReference.child("Employee List with Detail");
            //  id=databaseReference.push().getKey();
            databaseReference.child(id).setValue(stdinfo).addOnCompleteListener(new OnCompleteListener<Void>() {;
                //databaseReference.child(et_employee_no.getText().toString()+" "+et_name.getText().toString()).setValue(stdinfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()) {

                        Toast.makeText(AddEmployeeActivity.this, "User Registered Successfully", Toast.LENGTH_SHORT).show();
                        Intent i1=new Intent(AddEmployeeActivity.this,AdminActivity.class);
                        startActivity(i1);
                        pd.dismiss();
                    }else
                        Toast.makeText(AddEmployeeActivity.this, "Not Registered", Toast.LENGTH_SHORT).show();
                    Intent i1=new Intent(AddEmployeeActivity.this,AdminActivity.class);
                    startActivity(i1);
                    pd.dismiss();
                }

            });
            //Toast.makeText(AddStudentActivity.this, "Information Stored", Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Log.e("Exception is",e.toString());
            pd.dismiss();
        }

        firebaseAuth.signOut();
        //Toast.makeText(AddStudentActivity.this, "Signed Out", Toast.LENGTH_SHORT).show();
        //Log.e("Signed","out");

    }

}
