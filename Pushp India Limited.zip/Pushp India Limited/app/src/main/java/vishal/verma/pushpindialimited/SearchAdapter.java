/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import androidx.recyclerview.widget.RecyclerView;

public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.SearchViewHolder> {
    Context context;
    ArrayList<String> fullNameList;
    ArrayList<String> employeeNoList;
    ArrayList<String> profilePicList;
    ArrayList<String> Get_user_id;
    ArrayList<String>phoneList;
    ArrayList<String>aadharList;
    ArrayList<String>departmentList;
    ArrayList<String>emailList;
    ArrayList<String>user_idList;

    public SearchAdapter(Context context, ArrayList<String> fullNameList, ArrayList<String> employeeNoList,ArrayList<String> profilePicList,ArrayList<String>phoneList, ArrayList<String>aadharList,
            ArrayList<String>departmentList, ArrayList<String>emailList, ArrayList<String>user_idList, ArrayList<String> Get_user_id) {
        this.context = context;
        this.fullNameList = fullNameList;
        this.employeeNoList = employeeNoList;
        this.profilePicList = profilePicList;
        this.phoneList=phoneList;
        this.emailList=emailList;
        this.aadharList=aadharList;
        this.departmentList=departmentList;
        this.user_idList=user_idList;
        this.Get_user_id=Get_user_id;
    }



    class SearchViewHolder extends RecyclerView.ViewHolder {
        ImageView profilePic;
        TextView fullname, employeeNo,email,phone,aadhar,department,user_id;
LinearLayout SearchLinear;
        public SearchViewHolder(View itemView) {
            super(itemView);
            profilePic = (ImageView) itemView.findViewById(R.id.profilePic);
            fullname = (TextView) itemView.findViewById(R.id.fullName);
            employeeNo = (TextView) itemView.findViewById(R.id.employeeNo);
            email=(TextView)itemView.findViewById(R.id.email);
            phone=(TextView)itemView.findViewById(R.id.phone);
            aadhar=(TextView)itemView.findViewById(R.id.aadhar);
            department=(TextView)itemView.findViewById(R.id.department);
            user_id=(TextView)itemView.findViewById(R.id.user_id);
            SearchLinear=(LinearLayout)itemView.findViewById(R.id.SearchLinear);
        }
    }
        @Override
        public SearchAdapter.SearchViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.search_list_items,parent, false);

            return new SearchAdapter.SearchViewHolder(view);
        }

    @Override
    public void onBindViewHolder(SearchViewHolder holder, final int position) {
       // EmployeeInformation name=fullNameList.get(position);
        holder.fullname.setText(fullNameList.get(position));
        holder.employeeNo.setText(employeeNoList.get(position));
        Picasso.with(context).load(profilePicList.get(position)).placeholder(R.drawable.button_profile_logo).into(holder.profilePic);
        holder.user_id.setText(user_idList.get(position));
        holder.phone.setText(phoneList.get(position));
        holder.department.setText(departmentList.get(position));
        holder.email.setText(emailList.get(position));
        holder.aadhar.setText(aadharList.get(position));
        holder.SearchLinear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context=v.getContext();
                Intent searchIntent=new Intent(context,ProfileVisit.class);
                searchIntent.putExtra("fullname",fullNameList.get(position));
                searchIntent.putExtra("employeeno",employeeNoList.get(position));
                searchIntent.putExtra("user_id",user_idList.get(position));
                searchIntent.putExtra("phone",phoneList.get(position));
                searchIntent.putExtra("email",emailList.get(position));
                searchIntent.putExtra("aadhar",aadharList.get(position));
                searchIntent.putExtra("department",departmentList.get(position));
                searchIntent.putExtra("profilePic",profilePicList.get(position));
                searchIntent.putExtra("GetUserID",Get_user_id.get(position));
                context.startActivity(searchIntent);
            }
        });
    }





        @Override
        public int getItemCount() {
       // return fullNameList.size() ;
        //return employeeNoList.size();
            return profilePicList.size();
        }





}