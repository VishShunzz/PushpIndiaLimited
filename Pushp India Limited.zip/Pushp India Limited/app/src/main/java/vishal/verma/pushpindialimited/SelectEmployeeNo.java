/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SelectEmployeeNo extends AppCompatActivity {
    EditText et;
    Button bt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_employee_no);
        et=(EditText)findViewById(R.id.editText12);
        bt=(Button)findViewById(R.id.button7);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);


    }
    public void fn(View view){
        String employeeno=et.getText().toString();
        try{
            if(employeeno.isEmpty()){
                Toast.makeText(SelectEmployeeNo.this, "Employee No. cannot be empty", Toast.LENGTH_SHORT).show();
            }
            Intent intent=new Intent(this,SelectEmployeeNo .class);
            intent.putExtra("Name","Employeeno");
            intent.putExtra("Employeeno",employeeno);
            startActivity(intent);
            finish();
        }catch (Exception e){
            Log.e("Error is ",e.toString());
        }
    }
}
