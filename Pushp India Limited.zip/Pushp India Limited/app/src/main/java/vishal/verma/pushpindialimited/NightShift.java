/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

public class NightShift extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, com.google.android.gms.location.LocationListener {

    String longi, lati,current_state,sent;
    private static final int RL = 1;
    private static final String TAG = "NightShift";
    private GoogleApiClient mGoogleApiClient;
    private Location mLocation;
    private LocationManager locationManager;
    private LocationRequest mLocationRequest;
    private Uri downloadUri,uri,photoURI;

    private ImageView captureImage;
    private EditText currentReport ;
    private TextView currentLocationLa,currentLocationLo,currentTime;
    private StorageReference SR1;
    private String captureImageUrl;
    String id;
    private FirebaseStorage FS;
    private FirebaseDatabase FD;
    private DatabaseReference DR1;
    private StorageTask mCaptureTask;
    private Button requestB;

    private ProgressDialog mPD;
    private static final int REQUEST_CODE=101;
    //  private StorageReference SR;
    //private ProgressDialog PD;
    FirebaseUser user;
    LocationManager lm;
    FirebaseAuth firebaseAuth;
    private long UPDATE_INTERVAL = 2 * 1000;  /* 10 secs */
    private long FASTEST_INTERVAL = 2000; /* 2 sec */


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_night_shift);
        if (ActivityCompat.checkSelfPermission(NightShift.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED  ) {
            ActivityCompat.requestPermissions(NightShift.this, new String[]{Manifest.permission.CAMERA}, 1);
            return;
        }
        if (ActivityCompat.checkSelfPermission(NightShift.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED  ) {
            ActivityCompat.requestPermissions(NightShift.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
            return;
        }
        if (ActivityCompat.checkSelfPermission(NightShift.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED  ) {
            ActivityCompat.requestPermissions(NightShift.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            return;
        }


        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        requestB = (Button) findViewById(R.id.requestB);

        currentLocationLa = (TextView) findViewById(R.id.currentLocationLa);
        currentLocationLo = (TextView) findViewById(R.id.currentLocationLo);
        currentTime = (TextView) findViewById(R.id.currentDateTime);
        currentReport = (EditText) findViewById(R.id.report);
        captureImage = (ImageView) findViewById(R.id.captureImage);

       // Intent intent = getIntent();

sent="sent";

        firebaseAuth = FirebaseAuth.getInstance();
        // user = firebaseAuth.getCurrentUser();
        // set date and time
        Date time = Calendar.getInstance().getTime();
        currentTime.setText(time.toString());
        user = firebaseAuth.getCurrentUser();
        id = firebaseAuth.getUid();
        SR1 = FirebaseStorage.getInstance().getReferenceFromUrl("gs://pushpindialimited.appspot.com/Attendance Pics");
        DR1 = FirebaseDatabase.getInstance().getReferenceFromUrl("https://pushpindialimited.firebaseio.com/Employee Information/Night Shift");
current_state="new";
retrieveInformation();



        captureImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dispatchTakePictureIntent();
               // CaptureImage();
                //  saveUserInformation();
            }
        });






        requestB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(current_state=="new"||current_state=="rejected"){
                    {
                        if (TextUtils.isEmpty(currentReport.getText().toString())) {
                            Toast.makeText(NightShift.this, "Please Fill Reporting Field ", Toast.LENGTH_LONG).show();
                        } else {
                            if (TextUtils.isEmpty(currentLocationLa.getText().toString()) && TextUtils.isEmpty(currentLocationLo.getText().toString())) {
                                Toast.makeText(NightShift.this, "Your location provider doesn't work properly", Toast.LENGTH_LONG).show();
                            } else {
                                RretrieveTimeAndLocation();
                            }
                        }
                    }

                }else if(current_state=="request_send"){
                    cancelRequest();

                }
            }

        });
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks( this)
                .addOnConnectionFailedListener( this)
                .addApi(LocationServices.API)
                .build();
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        mPD = new ProgressDialog(this);

        if (ActivityCompat.checkSelfPermission(NightShift.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(NightShift.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(NightShift.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }else{
            checkLocation(); // Write you code here if permission already given.
        }



    }
private  void retrieveInformation(){
    Calendar calendar = Calendar.getInstance();
    SimpleDateFormat mdformat = new SimpleDateFormat("dd-MM-yyyy");
    SimpleDateFormat tmformat = new SimpleDateFormat("HHmmss");
    Intent intent = getIntent();
    DR1.child(mdformat.format(calendar.getTime()))//.child(intent.getExtras().getString("employeeno") + "  " + intent.getExtras().getString("name"))
            .addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Intent intent = getIntent();
                    if(dataSnapshot.hasChild(intent.getExtras().getString("employeeno") + "  " + intent.getExtras().getString("name"))){
                        String req=dataSnapshot.child(intent.getExtras().getString("employeeno") + "  " + intent.getExtras().getString("name"))
                                .child("request_type").getValue().toString();
                        if(req.equals(sent)){
                            current_state="request_send";
                            currentReport.setFocusable(false);
                            requestB.setText("Cancel Request");

                        }else if(req.equals("accepted")){
                            current_state="accepted";
                            currentReport.setFocusable(false);
                            currentReport.setText("Your night shift request is approved"+"\n"+"Now you can work in night shift");
                            requestB.setBackgroundColor(Color.GREEN);
                            requestB.setFocusable(false);
                            requestB.setText("You are Approved");

                        }else if(req.equals("rejected")){
                            current_state="rejected";
                            currentReport.setHint("Your night shift request is rejected"+"\n"+"For further discussion contact from your head");


                            requestB.setText("Send Again");

                        }
                    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

}
    private void RretrieveTimeAndLocation () {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat tmformat = new SimpleDateFormat("HHmmss");
        //String strDate = mdformat.format(calendar.getTime());

        Intent intent = getIntent();

        String locatla=lati;
        String locatlo=longi;
        String Date=currentTime.getText().toString();
        String report=currentReport.getText().toString();
        // String usid=intent.getExtras().getString("usid");
        String name=intent.getExtras().getString("name");
        String employeeno=intent.getExtras().getString("employeeno");
        String image=downloadUri.toString();
        final String request_type=sent;
        EmployeeInformation nightshift=new EmployeeInformation(locatla,locatlo,image,Date,report,request_type,name,employeeno);


        if(lati!=null&&longi!=null && downloadUri!=null) {//&&downloadUri!=null mind it
            DatabaseReference mref = DR1.child(mdformat.format(calendar.getTime()));//.child(tmformat.format(calendar.getTime()));//child(user.getUid())// mref.child(user.getUid()).setValue(Lt)
            mref.child(intent.getExtras().getString("employeeno") + "  " + intent.getExtras().getString("name")).setValue(nightshift).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Intent intent = getIntent();
                        String pil_user_id="PsoRH8vwulcpiUbSFXGz8bXKUbX2";
                        DR1.child("Notification").child(pil_user_id)
                                .child( intent.getExtras().getString("name"))
                                .setValue(id).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                Toast.makeText(NightShift.this, "Your request is send.", Toast.LENGTH_SHORT).show();
                                Intent i1 = new Intent(NightShift.this, Eemployee_Collection.class);
                                startActivity(i1);
                                current_state="request_send";
                            }
                        });
                        Toast.makeText(NightShift.this, "Your request is send.", Toast.LENGTH_SHORT).show();



                        //pd.dismiss();
                    } else
                        Toast.makeText(NightShift.this, "Some error " + "\n" + "Please try Again", Toast.LENGTH_SHORT).show();

                }
            });
        }else{
            Toast.makeText(this, "Please Fill Properly", Toast.LENGTH_LONG).show();
        }
    }

    private void cancelRequest() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat tmformat = new SimpleDateFormat("HHmmss");


        Intent intent = getIntent();

            DatabaseReference mref = DR1.child(mdformat.format(calendar.getTime()));//.child(tmformat.format(calendar.getTime()));//child(user.getUid())// mref.child(user.getUid()).setValue(Lt)
            mref.child(intent.getExtras().getString("employeeno") + "  " + intent.getExtras().getString("name")).removeValue()
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Intent intent = getIntent();

                        String pil_user_id="PsoRH8vwulcpiUbSFXGz8bXKUbX2";
                        String key=DR1.child("Notification").child(pil_user_id).push().getKey();
                        DR1.child("Notification").child(pil_user_id)
                                .child( intent.getExtras().getString("name"))
                                .removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                requestB.setEnabled(true);
                                Toast.makeText(NightShift.this, "Your request is cancelled.", Toast.LENGTH_SHORT).show();
                                current_state="new";
                                requestB.setText("Request Send");
                                Intent i1 = new Intent(NightShift.this, Eemployee_Collection.class);
                                startActivity(i1);
                            }
                        });
                        requestB.setEnabled(true);
                        Toast.makeText(NightShift.this, "Your request is cancelled.", Toast.LENGTH_SHORT).show();
                        current_state="new";
                        requestB.setText("Request Send");
                        Intent i1 = new Intent(NightShift.this, Eemployee_Collection.class);
                        startActivity(i1);
                        //pd.dismiss();
                    } else
                        Toast.makeText(NightShift.this, "Some error " + "\n" + "Please try Again", Toast.LENGTH_SHORT).show();
                    // Intent i1=new Intent(AddEmployeeActivity.this,AdminActivity.class);
                    //startActivity(i1);
                    //  mref.child(user.getUid())setValue(Lt);
                }
            });

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);


    }

    @Override
    public void onConnected(Bundle bundle) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        startLocationUpdates();

        mLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);

        if(mLocation == null){
            startLocationUpdates();
        }
        if (mLocation != null) {

            // mLatitudeTextView.setText(String.valueOf(mLocation.getLatitude()));
            //mLongitudeTextView.setText(String.valueOf(mLocation.getLongitude()));
        } else {
            Toast.makeText(this, "Location not Detected", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.i(TAG, "Connection Suspended");
        mGoogleApiClient.connect();
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.i(TAG, "Connection failed. Error: " + connectionResult.getErrorCode());
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mGoogleApiClient != null) {
            mGoogleApiClient.connect();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mGoogleApiClient.isConnected()) {
            mGoogleApiClient.disconnect();
        }
    }

    protected void startLocationUpdates() {
        // Create the location request
        mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(UPDATE_INTERVAL)
                .setFastestInterval(FASTEST_INTERVAL);
        // Request location updates
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient,
                mLocationRequest, (LocationListener) this);
        Log.d("reque", "--->>>>");
    }
    @Override
    public void onLocationChanged(Location location) {

        String msg = "Updated Location: " +
                Double.toString(location.getLatitude()) + "," +
                Double.toString(location.getLongitude());
        lati=String.valueOf(location.getLatitude());
        longi=String.valueOf(location.getLongitude());
        currentLocationLa.setText("Latitude :"+lati);
        currentLocationLo.setText("Longitude :"+longi);
        //  mLongitudeTextView.setText(String.valueOf(location.getLongitude() ));
        // Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        // You can now create a LatLng Object for use with maps
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
    }

    private boolean checkLocation() {
        if(!isLocationEnabled())
            showAlert();
        return isLocationEnabled();
    }

    private void showAlert() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Enable Location")
                .setMessage("Your Locations Settings is set to 'Off'.\nPlease Enable Location to " +
                        "use this app")
                .setPositiveButton("Location Settings", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {

                        Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(myIntent);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {

                    }
                });
        dialog.show();
    }


    private boolean isLocationEnabled() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }




    public void CaptureImage() {
        Intent CaptureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        CaptureIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        startActivityForResult(CaptureIntent, REQUEST_CODE);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {//&& data != null && data.getData() != null) {
          //  uri =  data.getData();
         //   captureImage.setImageURI(photoURI);
            CropImage.activity(photoURI)
                     .setGuidelines(CropImageView.Guidelines.ON)
                    .setAspectRatio(1, 1)
                    .start(this);
        }

       if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {


            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                Uri resultUri = result.getUri();

                captureImage.setImageURI(resultUri);
                uri = resultUri;


                mPD.setMessage("Saving...");
                mPD.setCanceledOnTouchOutside(false);
                mPD.setCancelable(false);
                mPD.show();
                //     Uri resulturi=result.getUri();


                final StorageReference profileImageRef =
                        FirebaseStorage.getInstance().getReference().child("Night Shift Attendance Pics/").child(resultUri.getLastPathSegment());//firebaseAuth.getCurrentUser().getUid()+ ".jpg");//.child(uri.getLastPathSegment());//+ ".jpg") ;
                profileImageRef.putFile(resultUri).
                        /*addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(AttendanceActivity.this, "Uploading in Progress ", Toast.LENGTH_SHORT).show();
                            }
                        }, 500);
                        // Curi=profileImageRef.getDownloadUrl().toString();
                        downloadUri = taskSnapshot.getMetadata().getReference().getDownloadUrl().getResult();


                        //return profileImageRef.getDownloadUrl();


                    }

                }).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(AttendanceActivity.this, "Successful", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(AttendanceActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }

                    }
                })*/

                                continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                            @Override
                            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                                if (!task.isSuccessful()) {
                                    mPD.dismiss();
                                    throw task.getException();

                                } else {
                                    Handler handler = new Handler();
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toast.makeText(NightShift.this, "Uploading in Progress ", Toast.LENGTH_SHORT).show();
                                            mPD.dismiss();
                                        }
                                    }, 500);
                                }
                                return profileImageRef.getDownloadUrl();
                            }
                        })
                        // Continue with the task to get the download URL
                        //   return profileImageRef.getDownloadUrl();


                        // }
                        .addOnCompleteListener(new OnCompleteListener<Uri>() {
                            @Override
                            public void onComplete(@NonNull final Task<Uri> task) {
                                if (task.isSuccessful()) {
                                    downloadUri = task.getResult();
                                    mPD.dismiss();


                                }
                            }
                        })


                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                mPD.dismiss();
                                Toast.makeText(NightShift.this, "Some error in uploading \n Try Again", Toast.LENGTH_SHORT).show();
                            }
                        });


            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
                Toast.makeText(NightShift.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }

    }

    String mCurrentPhotoPath;

    private File createImageFile() throws IOException {
// Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new     Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

// Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.getAbsolutePath();
        return image;
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
// Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File...
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                photoURI = FileProvider.getUriForFile(this,
                        "vishal.verma.pushpindialimited.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, REQUEST_CODE);
            }
        }
    }
}
