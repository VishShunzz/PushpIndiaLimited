/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

public class EmployeeInformation {
    private String locationla;
    private String locationlo;
    private String captureImageUrl;


    public EmployeeInformation(String locationla, String locationlo, String captureImageUrl, String time, String report, String request_type, String naame, String employeeno) {
        this.locationla = locationla;
        this.locationlo = locationlo;
        this.captureImageUrl = captureImageUrl;
        this.time = time;
        this.report = report;
        this.request_type = request_type;
        this.naame = naame;
        this.employeeno = employeeno;
    }

    private String time;
    private String report;

    public String getRequest_type() {
        return request_type;
    }

    public void setRequest_type(String request_type) {
        this.request_type = request_type;
    }

    private String request_type;

    public String getProfile_image() {
        return Profile_image;
    }

    public void setProfile_image(String profile_image) {
        Profile_image = profile_image;
    }

    private String Profile_image;




    public EmployeeInformation(String locationla,String locationlo, String time,String report,String employeeno,String naame ,String captureImageUrl) {
        //if any want to display with restriction use if statement in it you can apply here.
  this.employeeno=employeeno;
  this.naame=naame;
        this.locationla = locationla;
        this.locationlo = locationlo;
        this.report=report;
       this.captureImageUrl = captureImageUrl;
        this.time = time;

    }

    public String getReport() {
        return report;
    }

    public void setReport(String report) {
        this.report = report;
    }

    public String getLocationlo() {
        return locationlo;
    }

    public void setLocationlo(String locationlo) {
        this.locationlo = locationlo;
    }

    public String getLocationla() {
        return locationla;
    }

    public void setLocationla(String locationla) {
        this.locationla = locationla;
    }

    public String getCaptureImageUrl() {
        return captureImageUrl;
    }

    public void setCaptureImageUrl(String captureImageUrl) {
        this.captureImageUrl = captureImageUrl;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

   private String user_id;
    private String naame;
    private String employeeno;
    private String aadhar;
    private String phone;
    private String email;
    private String department;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }


    private String token;
    //ArrayList<Integer> departments;
    public EmployeeInformation(){

    }

    public String getGet_user_id() {
        return Get_user_id;
    }

    public void setGet_user_id(String get_user_id) {
        Get_user_id = get_user_id;
    }

    private  String Get_user_id;
    public EmployeeInformation(String email, String naame, String employeeno, String aadhar, String phone, String user_id, String department, String token, String Proile_image){//, ArrayList<Integer> departments) {
       this.user_id =user_id;
      this.token = token;
        this.naame = naame;
        this.employeeno = employeeno;
        this.aadhar = aadhar;
        this.phone = phone;
        this.email = email;
        this.department=department;
        this.Profile_image=Proile_image;

    }


    //public ArrayList<Integer> getDepartments() {
    //  return departments;
    //}

   // public String getProfilePic() {
     //   return profilePic;
    //}

    //public void setProfilePic(String profilePic) {
      //  this.profilePic = profilePic;
    //}

    //public void setDepartments(ArrayList<Integer> departments) {
    //  this.departments = departments;
    //}

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getNaame() {
        return naame;
    }

    public void setNaame(String naame) {
        this.naame = naame;
    }

    public String getEmployeeno() {
        return employeeno;
    }

    public void setEmployeeno(String employeeno) {
        this.employeeno = employeeno;
    }

    public String getAadhar() {
        return aadhar;
    }

    public void setAadhar(String aadhar) {
        this.aadhar = aadhar;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


}

