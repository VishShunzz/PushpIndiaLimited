/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;

import java.util.Calendar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class NightShiftDateTime extends AppCompatActivity {
   private TextView dateTxt;
    private CalendarView CV;
    private Button check;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_night_shift_date_time);
        Calendar calendar = Calendar.getInstance();


        calendar.set(Calendar.MONTH, Calendar.FEBRUARY);
        calendar.set(Calendar.DAY_OF_MONTH, 10);
        calendar.set(Calendar.YEAR, 2019);

        calendar.add(Calendar.MONTH,1);
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        calendar.add(Calendar.YEAR, 1);
        dateTxt=(TextView)findViewById(R.id.txt2);
        check=(Button)findViewById(R.id.prButton);
        CV=(CalendarView)findViewById(R.id.Pcv);
        CV.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int i, int i1, int i2) {
                int i3=i1+1;
                if((i2==1||i2==2||i2==3||i2==4||i2==5||i2==6||i2==7||i2==8||i2==9)&&(i3==1||i3==2||i3==3||i3==4||i3==5||i3==6||i3==7||i3==8||i3==9)){
                    // for(i3=1;i3<10;i3++) {
                    String Calender = "0" + i2 + "-0" + i3 + "-" + i;
                    dateTxt.setText(Calender);
                    // }
                } else if((i2==1||i2==2||i2==3||i2==4||i2==5||i2==6||i2==7||i2==8||i2==9)&&i3>9){
                    String Calender = "0" + i2 + "-" + i3 + "-" + i;
                    dateTxt.setText(Calender);

                }else
                if(i2>9&&(i3==1||i3==2||i3==3||i3==4||i3==5||i3==6||i3==7||i3==8||i3==9)){
                    String Calender =  i2 + "-0" + i3 + "-" + i;
                    dateTxt.setText(Calender);

                }else{
                    String Calender =  i2 + "-" + i3 + "-" + i;
                    dateTxt.setText(Calender);
                }
            }
        });
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent dateIntent1=new Intent(NightShiftDateTime.this,NightShiftDetail.class);
                dateIntent1.putExtra("date",dateTxt.getText().toString());
                startActivity(dateIntent1);
            }


        });
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);
    }
}
