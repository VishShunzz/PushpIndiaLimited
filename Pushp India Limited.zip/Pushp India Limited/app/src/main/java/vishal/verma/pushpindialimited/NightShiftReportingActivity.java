/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import de.hdodenhof.circleimageview.CircleImageView;

public class NightShiftReportingActivity extends AppCompatActivity {
    private TextView Naame,employeeNo,locationla,locationlo,date,report;
    private LinearLayout linearLayout;
    private CircleImageView cv;
    private  String current_state;
    private String pil_user_id;
    private   String userToken;
    private DatabaseReference DR1,DR2;
    private Button accept,reject;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_night_shift_reporting);


        pil_user_id = "PsoRH8vwulcpiUbSFXGz8bXKUbX2";
        current_state = "new";
        cv = (CircleImageView) findViewById(R.id.captureImage);
        Naame = (TextView) findViewById(R.id.fullName);
        employeeNo = (TextView) findViewById(R.id.employeeNo);
        locationla = (TextView) findViewById(R.id.location1LA);
        locationlo = (TextView) findViewById(R.id.location1LO);
        date = (TextView) findViewById(R.id.datetime);
        report = (TextView) findViewById(R.id.Report);
        linearLayout = (LinearLayout) findViewById(R.id.Ploca);
        accept = (Button) findViewById(R.id.accept);
        reject = (Button) findViewById(R.id.reject);
        Intent i = getIntent();
        Naame.setText(i.getExtras().getString("Naame"));
        employeeNo.setText(i.getExtras().getString("Employeeno"));
        locationlo.setText("Longitude : " + i.getExtras().getString("Locationlo"));
        locationla.setText("Latitude : " + i.getExtras().getString("Locationla"));
        date.setText(i.getExtras().getString("Time"));
        report.setText(i.getExtras().getString("Report"));
        DR1 = FirebaseDatabase.getInstance().getReferenceFromUrl("https://pushpindialimited.firebaseio.com/Employee Information/Night Shift");
        DR2  = FirebaseDatabase.getInstance().getReferenceFromUrl("https://pushpindialimited.firebaseio.com/Employee Information/Employee Detail");

        checkInformation();
        Picasso.with(this).load(i.getExtras().getString("CaptureImage")).placeholder(R.drawable.button_profile_logo).into(cv);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mapIntent = getIntent();
                Uri gmmIntentUri = Uri.parse("geo:0,0?q=" + mapIntent.getExtras().getString("Locationla") + "," + mapIntent.getExtras().getString("Locationlo"));
                Intent mapIntent2 = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent2.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent2);
            }
        });
        accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = getIntent();
                Calendar calendar = Calendar.getInstance();
                SimpleDateFormat mdformat = new SimpleDateFormat("dd-MM-yyyy");
                String strDate = mdformat.format(calendar.getTime());
                if (i.getExtras().getString("date").equals(strDate)) {
                    DR1.child(i.getExtras().getString("date")).child(i.getExtras().getString("Employeeno") + "  " + i.getExtras().getString("Naame"))
                            .child("request_type").setValue("accepted").addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Intent intent = getIntent();

                                DR1.child("acceptNotification").child(userToken)
                                        .child(intent.getExtras().getString("Employeeno") + "  " + intent.getExtras().getString("Naame"))
                                        .setValue(pil_user_id).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Intent intent = getIntent();
                                            DR1.child("Notification").child(pil_user_id)
                                                    .child(intent.getExtras().getString("Naame"))
                                                    .removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if (task.isSuccessful()) {

                                                        Calendar calendar = Calendar.getInstance();
                                                        SimpleDateFormat mdformat = new SimpleDateFormat("yyyy/MM/dd");
                                                        String strDate = mdformat.format(calendar.getTime());
                                                        DR2.child(userToken).child("Night Shift").child(strDate).setValue("N").addOnCompleteListener(new OnCompleteListener<Void>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                if(task.isSuccessful()){
                                                                    Intent intent = getIntent();
                                                                    Toast.makeText(NightShiftReportingActivity.this, "You accepted the request", Toast.LENGTH_LONG).show();

                                                                    current_state = "accepted";
                                                                    reject.setVisibility(View.INVISIBLE);
                                                                    accept.setBackgroundColor(Color.GREEN);
                                                                    accept.setVisibility(View.VISIBLE);
                                                                    accept.setText("Approved");
                                                                }

                                                            }
                                                        });


                                                    }
                                                }
                                            });

                                        }

                                    }


                                });
                            } else {
                                Toast.makeText(NightShiftReportingActivity.this, "You are too late to accept this request", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }
            }
        });
                    reject.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent i = getIntent();
                            Calendar calendar = Calendar.getInstance();
                            SimpleDateFormat mdformat = new SimpleDateFormat("dd-MM-yyyy");
                            String strDate = mdformat.format(calendar.getTime());
                            if (i.getExtras().getString("date").equals(strDate)) {
                                DR1.child(i.getExtras().getString("date")).child(i.getExtras().getString("Employeeno") + "  " + i.getExtras().getString("Naame"))
                                        .child("request_type").setValue("rejected").addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Intent intent = getIntent();


                                            DR1.child("rejectNotification").child(userToken)
                                                    .child(intent.getExtras().getString("Employeeno") + "  " + intent.getExtras().getString("Naame"))
                                                    .setValue(pil_user_id).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if (task.isSuccessful()) {
                                                        Intent intent = getIntent();
                                                        DR1.child("Notification").child(pil_user_id)
                                                                .child(intent.getExtras().getString("Employeeno") + "  " + intent.getExtras().getString("Naame"))
                                                                .removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                if (task.isSuccessful()) {
                                                                    Intent intent = getIntent();
                                                                    Toast.makeText(NightShiftReportingActivity.this, "You rejected the request", Toast.LENGTH_LONG).show();

                                                                    accept.setVisibility(View.VISIBLE);
                                                                    current_state = "rejected";
                                                                    accept.setBackgroundColor(Color.RED);
                                                                    reject.setVisibility(View.INVISIBLE);
                                                                    accept.setText("Rejected");

                                                                }
                                                            }
                                                        });

                                                    }

                                                }
                                            });

                                        }
                                    }
                                });
                            } else {
                                Toast.makeText(NightShiftReportingActivity.this, "You are too late to reject this request", Toast.LENGTH_LONG).show();
                            }
                        }
                    });


                    cv.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent i = getIntent();
                            Intent p1 = new Intent(NightShiftReportingActivity.this, PhotoViewActivity.class);
                            // imageView.buildDrawingCache();
                            //Bitmap bitmap = imageView.getDrawingCache();
                            p1.putExtra("name", Naame.getText().toString());
                            p1.putExtra("photo", i.getExtras().getString("CaptureImage"));
                            startActivity(p1);
                        }

                    });


    }

    private void checkInformation() {
        Intent i3 = getIntent();

        DR1.child(i3.getExtras().getString("date"))//.child(intent.getExtras().getString("employeeno") + "  " + intent.getExtras().getString("name"))
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Intent intent = getIntent();
                        if(dataSnapshot.hasChild(intent.getExtras().getString("Employeeno") + "  " + intent.getExtras().getString("Naame"))){
                            String req=dataSnapshot.child(intent.getExtras().getString("Employeeno") + "  " + intent.getExtras().getString("Naame"))
                                    .child("request_type").getValue().toString();
                            if(req.equals("accepted")){
                                current_state="accepted";
                                accept.setFocusable(false);
                                accept.setGravity(Gravity.CENTER);
                                accept.setBackgroundColor(Color.GREEN);
                                reject.setVisibility(View.INVISIBLE);
                                accept.setVisibility(View.VISIBLE);
                                accept.setText("Approved");

                            }else if(req.equals("rejected")){
                                accept.setVisibility(View.VISIBLE);
                                accept.setFocusable(false);
                                accept.setGravity(Gravity.CENTER);
                                current_state="rejected";
                                accept.setBackgroundColor(Color.RED);
                               reject.setVisibility(View.INVISIBLE);
                                accept.setText("Rejected");
                            }
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
        DR1.child("Notification")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Intent i3=getIntent();
                        if(dataSnapshot.hasChild(pil_user_id)) {

                             userToken=dataSnapshot.child(pil_user_id).child(i3.getExtras().getString("Naame")).getValue().toString();
                        }
                        }


                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);


    }
}
