/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.CalendarView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class MonthlyStatus extends AppCompatActivity {
    CalendarView CV;
    private TextView PresentC,AbsentC,NightShiftC,monthYear;
    private  String user,monthcheck;
    private DatabaseReference dr;
    private FirebaseUser user2;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monthly_status);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }



        Calendar calendar = Calendar.getInstance();
        PresentC=(TextView)findViewById(R.id.presentCount);
        AbsentC=(TextView)findViewById(R.id.absentCount);
        NightShiftC=(TextView)findViewById(R.id.nightShiftCount);
        monthYear=(TextView)findViewById(R.id.monthYear);
        monthcheck();

        Intent next=getIntent();
        monthYear.setText(monthcheck+", "+next.getExtras().getString("Year"));

//PresentC.setText("0");
//bsentC.setText("0");
//NightShiftC.setText("0");
       // calendar.set(Calendar.MONTH, Calendar.FEBRUARY);
      //  calendar.set(Calendar.DAY_OF_MONTH, 10);
       // calendar.set(Calendar.YEAR, 2019);

       // calendar.add(Calendar.MONTH, 1);
       // calendar.add(Calendar.DAY_OF_MONTH, 1);
      //  calendar.add(Calendar.YEAR, 1);

        mAuth= FirebaseAuth.getInstance();
        user=mAuth.getCurrentUser().getUid();

     //   Calendar calendar = Calendar.getInstance();


        dr= FirebaseDatabase.getInstance().getReferenceFromUrl("https://pushpindialimited.firebaseio.com/Employee Information/Employee Detail");
        checkInformation();
      //  CV = (CalendarView) findViewById(R.id.cv);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);

    }

   private void monthcheck() {
        Intent next=getIntent();
        String month=next.getExtras().getString("Month");
        if(month.equals("01")){
            monthcheck="JANUARY";
        }else
        if(month.equals("02")){
            monthcheck="FEBRUARY";
        }else  if(month.equals("03")){
            monthcheck="MARCH";
        }else   if(month.equals("04")){
            monthcheck="APRIL";
        }else   if(month.equals("05")){
            monthcheck="MAY";
        }else   if(month.equals("06")){
            monthcheck="JUNE";
        }else  if(month.equals("07")){
            monthcheck="JULY";
        }else  if(month.equals("08")){
            monthcheck="AUGUST";
        }else  if(month.equals("09")){
            monthcheck="SEPTEMBER";
        }else  if(month.equals("10")){
            monthcheck="OCTOBER";
        }else  if(month.equals("11")){
            monthcheck="November";
        }else  if(month.equals("12")){
            monthcheck="December";
        }else{
            Toast.makeText(this, "Wrong month number \n Please enter proper month number", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this,MonthYearActivity.class));
        }

    }

    private void checkInformation() {
        Intent next=getIntent();
        dr.child(user).child("Present/"+next.getExtras().getString("Year")+"/"+next.getExtras().getString("Month")).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    // Intent next=getIntent();
                    // Calendar calendar = Calendar.getInstance();
                    //   SimpleDateFormat mdformat = new SimpleDateFormat("yyyy/MM");
                    //  String strDate = mdformat.format(calendar.getTime());
                    //  if (dataSnapshot.hasChild("Present/"+next.getExtras().getString("Year")+"/"+next.getExtras().getString("Month"))) {

                    int size = (int) dataSnapshot.getChildrenCount();
                    PresentC.setText("" + size);
                }
            }
            //  if (dataSnapshot.hasChild("Absent/"+next.getExtras().getString("Year")+"/"+next.getExtras().getString("Month"))) {
            //  int size = (int) dataSnapshot.getChildrenCount();
            //  AbsentC.setText(size);

            //  }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        dr.child(user).child("Absent/"+next.getExtras().getString("Year")+"/"+next.getExtras().getString("Month")).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    // Intent next=getIntent();
                    // Calendar calendar = Calendar.getInstance();
                    //   SimpleDateFormat mdformat = new SimpleDateFormat("yyyy/MM");
                    //  String strDate = mdformat.format(calendar.getTime());
                    //  if (dataSnapshot.hasChild("Present/"+next.getExtras().getString("Year")+"/"+next.getExtras().getString("Month"))) {

                    int size = (int) dataSnapshot.getChildrenCount();
                    AbsentC.setText("" + size);

                }
                }
            //  if (dataSnapshot.hasChild("Absent/"+next.getExtras().getString("Year")+"/"+next.getExtras().getString("Month"))) {
            //  int size = (int) dataSnapshot.getChildrenCount();
            //  AbsentC.setText(size);

            //  }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        dr.child(user).child("Night Shift/"+next.getExtras().getString("Year")+"/"+next.getExtras().getString("Month")).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    // Intent next=getIntent();
                    // Calendar calendar = Calendar.getInstance();
                    //   SimpleDateFormat mdformat = new SimpleDateFormat("yyyy/MM");
                    //  String strDate = mdformat.format(calendar.getTime());
                    //  if (dataSnapshot.hasChild("Present/"+next.getExtras().getString("Year")+"/"+next.getExtras().getString("Month"))) {

                    int size = (int) dataSnapshot.getChildrenCount();
                   NightShiftC.setText("" + size);

                }
            }
            //  if (dataSnapshot.hasChild("Absent/"+next.getExtras().getString("Year")+"/"+next.getExtras().getString("Month"))) {
            //  int size = (int) dataSnapshot.getChildrenCount();
            //  AbsentC.setText(size);

            //  }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



    }

}
