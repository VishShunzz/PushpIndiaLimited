/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import androidx.appcompat.app.AppCompatActivity;
import de.hdodenhof.circleimageview.CircleImageView;

public class PresentReportingActivity extends AppCompatActivity {
    private TextView Naame,employeeNo,locationla,locationlo,date,report;
    private LinearLayout linearLayout;
    private CircleImageView cv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_present_reporting);
        cv=(CircleImageView)findViewById(R.id.captureImage);
        Naame=(TextView) findViewById(R.id.fullName);
        employeeNo=(TextView)findViewById(R.id.employeeNo);
        locationla=(TextView)findViewById(R.id.location1LA);
        locationlo=(TextView)findViewById(R.id.location1LO);
        date=(TextView)findViewById(R.id.datetime);
        report=(TextView)findViewById(R.id.Report);
        linearLayout=(LinearLayout)findViewById(R.id.Ploca);
        Intent i=getIntent();
        Naame.setText(i.getExtras().getString("Naame"));
        employeeNo.setText(i.getExtras().getString("Employeeno"));
        locationlo.setText("Longitude : "+i.getExtras().getString("Locationlo"));
        locationla.setText("Latitude : "+i.getExtras().getString("Locationla"));
        date.setText(i.getExtras().getString("Time"));
        report.setText(i.getExtras().getString("Report"));
        Picasso.with(this).load(i.getExtras().getString("CaptureImage")).placeholder(R.drawable.button_profile_logo).into(cv);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mapIntent = getIntent();
                Uri gmmIntentUri = Uri.parse("geo:0,0?q=" + mapIntent.getExtras().getString("Locationla") + "," + mapIntent.getExtras().getString("Locationlo"));
                Intent mapIntent2 = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent2.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent2);
            }
        });


        cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=getIntent();
                Intent p1=new Intent(PresentReportingActivity.this,PhotoViewActivity.class);
                // imageView.buildDrawingCache();
                //Bitmap bitmap = imageView.getDrawingCache();
                p1.putExtra("name",Naame.getText().toString());
                p1.putExtra("photo",i.getExtras().getString("CaptureImage"));
                startActivity(p1);
            }

        });

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);

    }
}
