/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

public class PresentAttendenceRecyclerAdapter extends RecyclerView.Adapter<PresentAttendenceRecyclerAdapter.MyHolder>{
    List<AttendenceList> attendencelistdata;
    Context context;
    public PresentAttendenceRecyclerAdapter(Context context,List<AttendenceList> attendencelistdata) {
        this.context = context;
        this.attendencelistdata = attendencelistdata;
    }

    @Override
    public PresentAttendenceRecyclerAdapter.MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.present_list, parent, false);

        PresentAttendenceRecyclerAdapter.MyHolder myHolder = new PresentAttendenceRecyclerAdapter.MyHolder(view);
        return myHolder;
    }


    public void onBindViewHolder(PresentAttendenceRecyclerAdapter.MyHolder holder, int position) {
        final AttendenceList data = attendencelistdata.get(position);
        holder.vnaame.setText(data.getNaame());
        holder.vemployeeno.setText(data.getEmployeeno());

        holder.vtime.setText(data.getTime());
        holder.vlocationla.setText(data.getLocationla());
        holder.vlocationlo.setText(data.getLocationlo());
        holder.vreport.setText(data.getReport());
        Picasso.with(context).load(data.getCaptureImageUrl()).placeholder(R.drawable.button_profile_logo).into(holder.Pik);
        holder.presentRelative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
       context=v.getContext();

                Intent i=new Intent(context,PresentReportingActivity.class);
                i.putExtra("Employeeno",data.getEmployeeno());
                i.putExtra("Naame",data.getNaame());
                i.putExtra("Report",data.getReport());
                i.putExtra("Time",data.getTime());
                i.putExtra("Locationla",data.getLocationla());
                i.putExtra("Locationlo",data.getLocationlo());
                i.putExtra("CaptureImage",data.getCaptureImageUrl());
                //  i.putExtra("Date",data.get);
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return attendencelistdata.size();
    }


    class MyHolder extends RecyclerView.ViewHolder {
        TextView vnaame, vemployeeno,vreport,vlocationla,vlocationlo,vtime;
        RelativeLayout presentRelative;
        CircleImageView Pik;
        public MyHolder(View itemView) {
            super(itemView);
            vreport = (TextView) itemView.findViewById(R.id.Report);
            vlocationla=(TextView)itemView.findViewById(R.id.LocationLa);
            vlocationlo=(TextView)itemView.findViewById(R.id.LocationLo);
            vtime=(TextView)itemView.findViewById(R.id.DateTime);
            vnaame = (TextView) itemView.findViewById(R.id.alt_name);
            vemployeeno = (TextView) itemView.findViewById(R.id.alt_employeeNo);
            Pik=(CircleImageView)itemView.findViewById(R.id.profilePic);
            presentRelative = (RelativeLayout) itemView.findViewById(R.id.presentParent);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // int visit= getPosition();
                    //  int visit =getAdapterPosition();
                    // Intent i2= new Intent(itemView.getContext(),AbsentReportingActivity.class);
                    // i2.putExtra("Date",visit);
                    // itemView.getContext().startActivity(i2);

                }
            });
        }
    }

}
