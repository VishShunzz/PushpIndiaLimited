/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

public class AttendenceList {
    String naame;
    String locationla,locationlo;

    public String getLocationla() {
        return locationla;
    }

    public void setLocationla(String locationla) {
        this.locationla = locationla;
    }

    public String getLocationlo() {
        return locationlo;
    }

    public void setLocationlo(String locationlo) {
        this.locationlo = locationlo;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getReport() {
        return report;
    }

    public void setReport(String report) {
        this.report = report;
    }

    String time;

    public AttendenceList(String naame, String locationla,String locationlo, String time, String report, String employeeno,String captureImageUrl) {
        this.naame = naame;
        this.locationla = locationla;
        this.locationlo = locationlo;
        this.time = time;
        this.report = report;
        this.employeeno = employeeno;
        this.captureImageUrl=captureImageUrl;
    }

    String report;
    String employeeno;

    public String getCaptureImageUrl() {
        return captureImageUrl;
    }

    public void setCaptureImageUrl(String captureImageUrl) {
        this.captureImageUrl = captureImageUrl;
    }

    String captureImageUrl;
    public String getNaame() {
        return naame;
    }

    public void setNaame(String naame) {
        this.naame = naame;
    }

    public String getEmployeeno() {
        return employeeno;
    }

    public void setEmployeeno(String employeeno) {
        this.employeeno = employeeno;
    }


    public AttendenceList() {
    }



    public AttendenceList(String naame, String enployeeno) {
        this.naame = naame;
        this.employeeno = enployeeno;
    }
}
