/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {
    private ImageView logo;
    private static int splashtimeout = 5000;

    @Override

    protected void onCreate(@Nullable Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_splash);

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent i1 = new Intent(SplashActivity.this, MainActivity.class);
                    startActivity(i1);
                    finish();
                }
            }, splashtimeout);
            logo = (ImageView) findViewById(R.id.splash_image);
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.splashanimation);
            logo.startAnimation(anim);
        }
    }
