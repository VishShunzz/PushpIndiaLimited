/*
 * © 2019 Pushp India Limited. All rights reserved.  Developed by Vishal Verma.
 */

package vishal.verma.pushpindialimited;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class EmployeeInformationActivity extends AppCompatActivity {
    private static final int CHOOSE_IMAGE = 101;
    // EmployeeInformation std;
    String id;
    String image;
    // String value = "";
    private Context mContext;
    private Bitmap bitmap;
    // String name = "";
    TextView tvname, tvemployeeno, tvaadhar, tvcontact, tvuser_id,tvdepartment, tvemail;
    ImageView imageView;
    Uri uriProfileImage,downloadUri;
    String profileImageUrl;
    public ProgressDialog pd;
    private FirebaseDatabase firebaseDatabase;
    private FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener listener;
    private DatabaseReference databaseReference;
    private FirebaseUser user;
    private StorageTask uploadTask;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_information);
       // SR= FirebaseStorage.getInstance().getReference();
        imageView = (ImageView) findViewById(R.id.imageView);
        // std = new EmployeeInformation();
        // std.setName("Vishal");
        pd = new ProgressDialog(this, ProgressDialog.STYLE_SPINNER);
        pd.setMessage("Fetching Information");
        pd.setCancelable(true);
        pd.setCanceledOnTouchOutside(true);
Intent proIntent=getIntent();

       setTitle(proIntent.getExtras().getString("Name"));
        tvname=(TextView)findViewById(R.id.textView14);
        tvuser_id =(TextView)findViewById(R.id.textViewid);
        tvdepartment=(TextView)findViewById(R.id.textViewMent);
        tvemail =(TextView)findViewById(R.id.textViewEid);
        tvemployeeno =(TextView)findViewById(R.id.textView17);
        tvaadhar =(TextView)findViewById(R.id.textView18);
        tvcontact=(TextView)findViewById(R.id.textView20);
        //  lv=(ListView)findViewById(R.id.listView3);
        firebaseAuth= FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
        user=firebaseAuth.getCurrentUser();
        id=firebaseAuth.getUid();
        imageView.setOnLongClickListener(new View.OnLongClickListener(){
            @Override
            public boolean onLongClick(View v) {
                Intent p1=new Intent(EmployeeInformationActivity.this,PhotoViewActivity.class);
                // imageView.buildDrawingCache();
                 //Bitmap bitmap = imageView.getDrawingCache();
                p1.putExtra("name",tvname.getText().toString());
                p1.putExtra("photo",image);
                startActivity(p1);
                return true;
            }


        });





       // StateListener();
      // sharedPreferences();
        fetchData();
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showImageChooser();
               // loadUserInformation();
               // saveUserInformation();
                //Intent i1 = new Intent(EmployeeInformationActivity.this, ChangeProfilePic.class);
               // startActivity(i1);
            }
        });
       // loadUserInformation();
       // saveUserInformation();

        // loadUserInformation();
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

    }
//create sharedPreferences(
//create retrivesharedPreferences() this method
 /*   private void sharedPreferences()
    {
        SharedPreferences shared = getSharedPreferences("App_settings", MODE_PRIVATE);
        SharedPreferences.Editor editor = shared.edit();
        editor.putString("PRODUCT_PHOTO", encodeTobase64(bitmap));
        editor.commit();
    }
//create retrivesharedPreferences()
    private void retrivesharedPreferences()
    {
        SharedPreferences shared = getSharedPreferences("MyApp_Settings", MODE_PRIVATE);
        String photo = shared.getString("PRODUCT_PHOTO", "photo");
        assert photo != null;
        if(!photo.equals("photo"))
        {
            byte[] b = Base64.decode(photo, Base64.DEFAULT);
            InputStream is = new ByteArrayInputStream(b);
            bitmap = BitmapFactory.decodeStream(is);
          imageView.setImageBitmap(bitmap);
        }

    }
//Write encodeTobase64() Method to encode your bitmap into string base64- and put code in this method
    public static String encodeTobase64(Bitmap image) {
        Bitmap bitmap_image = image;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap_image.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] b = baos.toByteArray();
        String imageEncoded = Base64.encodeToString(b, Base64.DEFAULT);

        return imageEncoded;
    }
*/
 /*   public void StateListener() {
        listener = new FirebaseAuth.AuthStateListener() {

            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user == null) {
                    Toast.makeText(EmployeeInformationActivity.this, "You must be a Company member than Login", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        };
    } */
    public void fetchData() {
pd.setMessage("Fetching...");
pd.setCancelable(true);
pd.setCanceledOnTouchOutside(false);
pd.show();

        //databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {

        databaseReference.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                // try
                // Toast.makeText(StudentInformationActivity.this, "Hello bro Again", Toast.LENGTH_SHORT).show();
                // Iterable<DataSnapshot> children = dataSnapshot.getChildren();
                for (DataSnapshot stdSnapshot : dataSnapshot.getChildren()) {
                    EmployeeInformation std = stdSnapshot.child("Employee Detail").child(id).getValue(EmployeeInformation.class);
                   // EmployeeInformation std = new EmployeeInformation();
                   // std.setNaame(stdSnapshot.child(id).getValue(EmployeeInformation.class).getNaame());
                   // std.setEmployeeno(stdSnapshot.child(id).getValue(EmployeeInformation.class).getEmployeeno());
                   // std.setPhone(stdSnapshot.child(id).getValue(EmployeeInformation.class).getPhone());
                   // std.setAadhar(stdSnapshot.child(id).getValue(EmployeeInformation.class).getAadhar());
                   // std.setDepartment(stdSnapshot.child(id).getValue(EmployeeInformation.class).getDepartment());
                   // std.setEmail(stdSnapshot.child(id).getValue(EmployeeInformation.class).getEmail());
                  //  std.setUser_id(stdSnapshot.child(id).getValue(EmployeeInformation.class).getUser_id());
                    tvname.setText(std.getNaame());
                    tvemployeeno.setText(std.getEmployeeno());
                    tvaadhar.setText(std.getAadhar());
                    tvcontact.setText(std.getPhone());
                    tvemail.setText(std.getUser_id());
                    tvdepartment.setText(std.getDepartment());
                    tvuser_id.setText(std.getEmail());
                    image = std.getProfile_image();
                    Picasso.with(EmployeeInformationActivity.this).load(image).placeholder(R.drawable.button_profile_logo).into(imageView);
          pd.dismiss();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
pd.dismiss();
            }


        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.employee_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                startActivity(new Intent(this, Eemployee_Collection.class));
                break;

            case R.id.menuLogout:

                FirebaseAuth.getInstance().signOut();
                finish();
                startActivity(new Intent(this, MainActivity.class));

                break;
            case R.id.menuSetting:
                startActivity(new Intent(this, SettingActivity.class));

                break;

            case R.id.feedback:
                 startActivity(new Intent(this, FeedBack_Activity.class));

                break;
            case R.id.Aboutus:
                 startActivity(new Intent(this,AboutUsActivity.class));

                break;
        }

        return true;
    }


  @Override
  protected void onStart() {
      super.onStart();
      if (firebaseAuth.getCurrentUser() == null) {
          finish();
          startActivity(new Intent(this, MainActivity.class));
      }
  }


    private void sharedPreferences()
    {
        pd.setMessage("Wait...");
        pd.setCancelable(false);
        pd.setCanceledOnTouchOutside(false);
        pd.show();
        SharedPreferences shared = getSharedPreferences("myprefs", MODE_PRIVATE);
        String img_str=shared.getString("pro_pic", "");
        if (!img_str.equals("")){
            //decode string to image
            String base=img_str;
            byte[] imageAsBytes = Base64.decode(base.getBytes(), Base64.DEFAULT);
           imageView.setImageBitmap(BitmapFactory.decodeByteArray(imageAsBytes, 0, imageAsBytes.length) );

       pd.dismiss(); }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CHOOSE_IMAGE && resultCode == RESULT_OK && data != null) {
            uriProfileImage = data.getData();

            CropImage.activity(uriProfileImage)
                   // .setGuidelines(CropImageView.Guidelines.ON)
                   .setAspectRatio(1, 1)

                    .start(this);

                   // .start(getContext(), this);
        }
        if(requestCode==CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE){
            CropImage.ActivityResult result=CropImage.getActivityResult(data);
            if(resultCode==RESULT_OK)
            {
                pd.setMessage("Saving...");
                pd.setCanceledOnTouchOutside(false);
                pd.setCancelable(false);
                pd.show();
                Uri resulturi=result.getUri();
                final StorageReference profileImageRef =
                        FirebaseStorage.getInstance().getReference().child("profilepics/" + firebaseAuth.getCurrentUser().getUid() + ".jpg");
           profileImageRef.putFile(resulturi).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                    @Override
                    public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                        if (!task.isSuccessful()) {
                            throw task.getException();

                        }else {
                            Handler handler=new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(EmployeeInformationActivity.this, "Uploading in Progress ", Toast.LENGTH_SHORT).show();
                                }
                            },500);
                        }

                        // Continue with the task to get the download URL
                        return profileImageRef.getDownloadUrl();



                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                    @Override
                    public void onComplete(@NonNull final Task<Uri> task) {
                        if (task.isSuccessful()) {
                       downloadUri = task.getResult();

                            databaseReference.child("Employee Information/Employee Detail/" + firebaseAuth.getCurrentUser().getUid()).child("Profile_image")
                                    .setValue(downloadUri.toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {

                                        pd.dismiss();
                                        Toast.makeText(EmployeeInformationActivity.this, "Successful", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(mContext, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });

                        }
                    }
                } );

            }
        }
    }



    private void showImageChooser() {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(intent, CHOOSE_IMAGE);
    }

}